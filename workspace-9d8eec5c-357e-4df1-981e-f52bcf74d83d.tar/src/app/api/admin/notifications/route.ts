import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// Get all notifications
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const unreadOnly = searchParams.get("unread") === "true";

    const notifications = await db.notification.findMany({
      where: unreadOnly ? { isRead: false } : undefined,
      include: {
        user: {
          select: { name: true, email: true },
        },
      },
      orderBy: { createdAt: "desc" },
      take: 50,
    });

    const unreadCount = await db.notification.count({
      where: { isRead: false },
    });

    return NextResponse.json({
      notifications,
      unreadCount,
    });
  } catch (error) {
    console.error("Get notifications error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

// Create notification (broadcast to all users or specific user)
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { title, message, type, userId, broadcast } = body;

    if (!title || !message) {
      return NextResponse.json(
        { error: "Title and message are required" },
        { status: 400 }
      );
    }

    if (broadcast) {
      // Send to all users
      const users = await db.user.findMany({
        where: { role: "user" },
        select: { id: true },
      });

      const notifications = await Promise.all(
        users.map((user) =>
          db.notification.create({
            data: {
              userId: user.id,
              title,
              message,
              type: type || "info",
            },
          })
        )
      );

      return NextResponse.json({
        message: `Notification sent to ${notifications.length} users`,
        count: notifications.length,
      });
    } else if (userId) {
      // Send to specific user
      const notification = await db.notification.create({
        data: {
          userId,
          title,
          message,
          type: type || "info",
        },
      });

      return NextResponse.json({
        message: "Notification sent",
        notification,
      });
    } else {
      return NextResponse.json(
        { error: "Either userId or broadcast must be specified" },
        { status: 400 }
      );
    }
  } catch (error) {
    console.error("Create notification error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

// Mark notification as read
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { notificationId, markAllRead } = body;

    if (markAllRead) {
      await db.notification.updateMany({
        where: { isRead: false },
        data: { isRead: true },
      });

      return NextResponse.json({
        message: "All notifications marked as read",
      });
    }

    if (!notificationId) {
      return NextResponse.json(
        { error: "Notification ID is required" },
        { status: 400 }
      );
    }

    await db.notification.update({
      where: { id: notificationId },
      data: { isRead: true },
    });

    return NextResponse.json({
      message: "Notification marked as read",
    });
  } catch (error) {
    console.error("Update notification error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

// Delete notification
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const notificationId = searchParams.get("id");

    if (!notificationId) {
      return NextResponse.json(
        { error: "Notification ID is required" },
        { status: 400 }
      );
    }

    await db.notification.delete({
      where: { id: notificationId },
    });

    return NextResponse.json({
      message: "Notification deleted",
    });
  } catch (error) {
    console.error("Delete notification error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
