import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const period = searchParams.get("period") || "7d";

    // Calculate date range
    const now = new Date();
    let startDate = new Date();
    
    switch (period) {
      case "30d":
        startDate.setDate(now.getDate() - 30);
        break;
      case "90d":
        startDate.setDate(now.getDate() - 90);
        break;
      case "7d":
      default:
        startDate.setDate(now.getDate() - 7);
    }

    // Get daily stats for the period
    const summaries = await db.videoSummary.findMany({
      where: {
        createdAt: { gte: startDate },
      },
      select: {
        createdAt: true,
      },
    });

    const users = await db.user.findMany({
      where: {
        createdAt: { gte: startDate },
      },
      select: {
        createdAt: true,
        role: true,
      },
    });

    // Group by day
    const dailyStats: Record<string, { summaries: number; newUsers: number }> = {};
    
    // Initialize all days in range
    for (let d = new Date(startDate); d <= now; d.setDate(d.getDate() + 1)) {
      const dateKey = d.toISOString().split("T")[0];
      dailyStats[dateKey] = { summaries: 0, newUsers: 0 };
    }

    // Count summaries per day
    summaries.forEach((s) => {
      const dateKey = s.createdAt.toISOString().split("T")[0];
      if (dailyStats[dateKey]) {
        dailyStats[dateKey].summaries++;
      }
    });

    // Count new users per day
    users.forEach((u) => {
      const dateKey = u.createdAt.toISOString().split("T")[0];
      if (dailyStats[dateKey]) {
        dailyStats[dateKey].newUsers++;
      }
    });

    // Get plan distribution
    const subscriptions = await db.subscription.findMany({
      select: { plan: true },
    });

    const planDistribution = {
      free: 0,
      monthly: 0,
      yearly: 0,
    };

    subscriptions.forEach((s) => {
      if (s.plan in planDistribution) {
        planDistribution[s.plan as keyof typeof planDistribution]++;
      }
    });

    // Get language distribution
    const languageStats = await db.videoSummary.groupBy({
      by: ["summaryLanguage"],
      _count: true,
    });

    const languageDistribution = languageStats.reduce((acc, curr) => {
      acc[curr.summaryLanguage] = curr._count;
      return acc;
    }, {} as Record<string, number>);

    // Get top users by activity
    const topUsers = await db.user.findMany({
      take: 10,
      select: {
        id: true,
        name: true,
        email: true,
        _count: {
          select: { summaries: true },
        },
      },
      orderBy: {
        summaries: { _count: "desc" },
      },
    });

    // Convert dailyStats to array for charts
    const chartData = Object.entries(dailyStats)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([date, stats]) => ({
        date,
        summaries: stats.summaries,
        newUsers: stats.newUsers,
      }));

    return NextResponse.json({
      period,
      chartData,
      planDistribution,
      languageDistribution,
      topUsers,
      totalSummariesInPeriod: summaries.length,
      totalNewUsersInPeriod: users.length,
    });
  } catch (error) {
    console.error("Reports error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
