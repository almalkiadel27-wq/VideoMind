import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// Default settings
const DEFAULT_SETTINGS = {
  siteName: "VideoMind",
  siteDescription: "AI-Powered Video Intelligence",
  dailyLimitFree: "5",
  dailyLimitPremium: "50",
  maxVideoLength: "60", // minutes
  allowedDomains: "youtube.com, youtu.be",
  maintenanceMode: "false",
  registrationEnabled: "true",
  emailNotificationsEnabled: "true",
};

// Get all settings
export async function GET() {
  try {
    const settings = await db.systemSetting.findMany();
    
    // Convert to object with defaults
    const settingsMap: Record<string, string> = { ...DEFAULT_SETTINGS };
    settings.forEach((s) => {
      settingsMap[s.key] = s.value;
    });

    return NextResponse.json({
      settings: settingsMap,
    });
  } catch (error) {
    console.error("Get settings error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

// Update settings
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { settings } = body;

    if (!settings || typeof settings !== "object") {
      return NextResponse.json(
        { error: "Settings object is required" },
        { status: 400 }
      );
    }

    // Update each setting
    const updates = await Promise.all(
      Object.entries(settings).map(([key, value]) =>
        db.systemSetting.upsert({
          where: { key },
          update: { value: String(value) },
          create: { key, value: String(value) },
        })
      )
    );

    return NextResponse.json({
      message: "Settings updated successfully",
      updated: updates.length,
    });
  } catch (error) {
    console.error("Update settings error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

// Reset to defaults
export async function DELETE() {
  try {
    await db.systemSetting.deleteMany();

    // Create default settings
    await Promise.all(
      Object.entries(DEFAULT_SETTINGS).map(([key, value]) =>
        db.systemSetting.create({
          data: { key, value },
        })
      )
    );

    return NextResponse.json({
      message: "Settings reset to defaults",
      settings: DEFAULT_SETTINGS,
    });
  } catch (error) {
    console.error("Reset settings error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
