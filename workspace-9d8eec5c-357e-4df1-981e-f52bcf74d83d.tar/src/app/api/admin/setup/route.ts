import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import bcrypt from "bcryptjs";

// Create admin account (only if no admin exists)
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, password, name, secretKey } = body;

    // Check secret key for security
    if (secretKey !== "admin-setup-2024") {
      return NextResponse.json(
        { error: "Invalid secret key" },
        { status: 401 }
      );
    }

    // Check if any admin already exists
    const existingAdmin = await db.user.findFirst({
      where: { role: "admin" },
    });

    if (existingAdmin) {
      return NextResponse.json(
        { error: "Admin account already exists" },
        { status: 400 }
      );
    }

    // Check if email is already used
    const existingUser = await db.user.findUnique({
      where: { email },
    });

    if (existingUser) {
      // Update existing user to admin
      const hashedPassword = await bcrypt.hash(password, 10);
      const updatedUser = await db.user.update({
        where: { email },
        data: {
          role: "admin",
          password: hashedPassword,
          name: name || existingUser.name,
        },
      });
      return NextResponse.json({
        message: "User promoted to admin",
        user: { id: updatedUser.id, email: updatedUser.email, name: updatedUser.name, role: updatedUser.role },
      });
    }

    // Create new admin
    const hashedPassword = await bcrypt.hash(password, 10);
    const admin = await db.user.create({
      data: {
        email,
        password: hashedPassword,
        name: name || "Admin",
        role: "admin",
      },
    });

    return NextResponse.json({
      message: "Admin account created successfully",
      user: { id: admin.id, email: admin.email, name: admin.name, role: admin.role },
    });
  } catch (error) {
    console.error("Admin setup error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
