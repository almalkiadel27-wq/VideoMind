import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(request: NextRequest) {
  try {
    // Get total users count
    const totalUsers = await db.user.count();
    
    // Get users by role
    const adminCount = await db.user.count({
      where: { role: "admin" },
    });
    
    const regularUsers = totalUsers - adminCount;

    // Get total summaries
    const totalSummaries = await db.videoSummary.count();

    // Get summaries today
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const summariesToday = await db.videoSummary.count({
      where: {
        createdAt: {
          gte: today,
        },
      },
    });

    // Get subscription stats
    const activeSubscriptions = await db.subscription.count({
      where: { isActive: true },
    });

    const premiumSubscriptions = await db.subscription.count({
      where: {
        isActive: true,
        plan: { in: ["monthly", "yearly"] },
      },
    });

    // Get recent users (last 7 days)
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    const recentUsers = await db.user.count({
      where: {
        createdAt: {
          gte: sevenDaysAgo,
        },
      },
    });

    // Get recent activity (last 10 summaries)
    const recentSummaries = await db.videoSummary.findMany({
      take: 10,
      orderBy: { createdAt: "desc" },
      include: {
        user: {
          select: { name: true, email: true },
        },
      },
    });

    // Get recent users list
    const recentUsersList = await db.user.findMany({
      take: 10,
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        createdAt: true,
        subscription: {
          select: { plan: true, isActive: true },
        },
      },
    });

    return NextResponse.json({
      stats: {
        totalUsers,
        adminCount,
        regularUsers,
        totalSummaries,
        summariesToday,
        activeSubscriptions,
        premiumSubscriptions,
        recentUsers,
      },
      recentSummaries,
      recentUsers: recentUsersList,
    });
  } catch (error) {
    console.error("Admin stats error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
