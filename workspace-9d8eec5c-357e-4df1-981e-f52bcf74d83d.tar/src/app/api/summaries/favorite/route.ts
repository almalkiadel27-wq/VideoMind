import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const { summaryId } = await request.json();

    if (!summaryId) {
      return NextResponse.json(
        { error: "Summary ID is required" },
        { status: 400 }
      );
    }

    // Verify ownership
    const summary = await db.videoSummary.findFirst({
      where: { id: summaryId, userId: session.user.id },
    });

    if (!summary) {
      return NextResponse.json(
        { error: "Summary not found" },
        { status: 404 }
      );
    }

    const updatedSummary = await db.videoSummary.update({
      where: { id: summaryId },
      data: { isFavorite: !summary.isFavorite },
    });

    return NextResponse.json({
      success: true,
      isFavorite: updatedSummary.isFavorite,
    });
  } catch (error) {
    console.error("Error toggling favorite:", error);
    return NextResponse.json(
      { error: "Failed to toggle favorite" },
      { status: 500 }
    );
  }
}
