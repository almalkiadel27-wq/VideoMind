import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const summaries = await db.videoSummary.findMany({
      where: { userId: session.user.id },
      orderBy: { createdAt: "desc" },
    });

    const formattedSummaries = summaries.map((s) => ({
      id: s.id,
      videoUrl: s.videoUrl,
      videoTitle: s.videoTitle,
      videoThumbnail: s.videoThumbnail,
      originalLanguage: s.originalLanguage,
      summaryLanguage: s.summaryLanguage,
      mainIdea: s.mainIdea,
      keyPoints: JSON.parse(s.keyPoints),
      conclusion: s.conclusion,
      timeline: s.timeline ? JSON.parse(s.timeline) : null,
      fullSummary: s.fullSummary,
      keywords: s.keywords ? JSON.parse(s.keywords) : [],
      transcriptSource: s.transcriptSource,
      isFavorite: s.isFavorite,
      createdAt: s.createdAt.toISOString(),
    }));

    return NextResponse.json({
      success: true,
      summaries: formattedSummaries,
    });
  } catch (error) {
    console.error("Error fetching summaries:", error);
    return NextResponse.json(
      { error: "Failed to fetch summaries" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    // Get summaryId from query string or body
    const { searchParams } = new URL(request.url);
    let summaryId = searchParams.get("summaryId");
    
    // If not in query string, try to get from body
    if (!summaryId) {
      try {
        const body = await request.json();
        summaryId = body.summaryId;
      } catch {
        // No body available
      }
    }

    if (!summaryId) {
      return NextResponse.json(
        { error: "Summary ID is required" },
        { status: 400 }
      );
    }

    // Verify ownership
    const summary = await db.videoSummary.findFirst({
      where: { id: summaryId, userId: session.user.id },
    });

    if (!summary) {
      return NextResponse.json(
        { error: "Summary not found" },
        { status: 404 }
      );
    }

    await db.videoSummary.delete({
      where: { id: summaryId },
    });

    return NextResponse.json({
      success: true,
      message: "Summary deleted successfully",
    });
  } catch (error) {
    console.error("Error deleting summary:", error);
    return NextResponse.json(
      { error: "Failed to delete summary" },
      { status: 500 }
    );
  }
}
