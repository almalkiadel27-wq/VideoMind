import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import { processVideoWithRAG, extractVideoInfo, SummaryResult } from "@/lib/rag-system";

// Languages supported
const LANGUAGE_NAMES: Record<string, string> = {
  en: "English",
  ar: "Arabic (العربية)",
  es: "Spanish",
  fr: "French",
  de: "German",
  zh: "Chinese",
  ja: "Japanese",
  ko: "Korean",
  pt: "Portuguese",
  ru: "Russian",
  it: "Italian",
  hi: "Hindi",
  tr: "Turkish",
  nl: "Dutch",
  pl: "Polish",
};

export async function POST(request: NextRequest) {
  const startTime = Date.now();
  
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Unauthorized - Please log in" },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { videoUrl, targetLanguage = "en" } = body;

    if (!videoUrl) {
      return NextResponse.json(
        { error: "Video URL is required" },
        { status: 400 }
      );
    }

    // Validate URL
    try {
      new URL(videoUrl);
    } catch {
      return NextResponse.json(
        { error: "Invalid URL format" },
        { status: 400 }
      );
    }

    // Check daily limit
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const todayUsage = await db.usageRecord.count({
      where: {
        userId: session.user.id,
        action: "summarize",
        date: { gte: today },
      },
    });
    
    const limit = 5;
    if (todayUsage >= limit) {
      return NextResponse.json(
        { error: "Daily limit reached. Please try again tomorrow." },
        { status: 403 }
      );
    }

    const targetLangName = LANGUAGE_NAMES[targetLanguage] || "English";
    console.log(`[API] Processing video: ${videoUrl} in ${targetLangName}`);

    // Process video with RAG pipeline
    let result: { summary: SummaryResult; videoInfo: ReturnType<typeof extractVideoInfo>; chunkCount: number };
    
    try {
      result = await processVideoWithRAG(videoUrl, targetLangName);
    } catch (error) {
      console.error("[API] RAG processing error:", error);
      return NextResponse.json(
        { error: error instanceof Error ? error.message : "Failed to process video" },
        { status: 400 }
      );
    }

    const { summary, videoInfo, chunkCount } = result;

    // Save summary to database
    const savedSummary = await db.videoSummary.create({
      data: {
        userId: session.user.id,
        videoUrl,
        videoTitle: summary.videoTitle || `${videoInfo.platform} Video`,
        videoThumbnail: videoInfo.thumbnail,
        originalLanguage: summary.originalLanguage,
        summaryLanguage: targetLanguage,
        transcript: summary.fullSummary,
        transcriptSource: 'rag_system',
        mainIdea: summary.mainIdea,
        keyPoints: JSON.stringify(summary.keyPoints),
        conclusion: summary.conclusion,
        fullSummary: summary.fullSummary,
        keywords: JSON.stringify(summary.keywords),
      },
    });

    // Record usage
    await db.usageRecord.create({
      data: {
        userId: session.user.id,
        action: "summarize",
      },
    });

    const processingTime = ((Date.now() - startTime) / 1000).toFixed(1);
    console.log(`[API] Summary completed in ${processingTime}s`);

    return NextResponse.json({
      success: true,
      summary: {
        id: savedSummary.id,
        videoUrl: savedSummary.videoUrl,
        videoTitle: savedSummary.videoTitle,
        videoThumbnail: savedSummary.videoThumbnail,
        originalLanguage: savedSummary.originalLanguage,
        summaryLanguage: savedSummary.summaryLanguage,
        platform: videoInfo.platform,
        mainIdea: savedSummary.mainIdea,
        keyPoints: JSON.parse(savedSummary.keyPoints),
        conclusion: savedSummary.conclusion,
        fullSummary: savedSummary.fullSummary,
        keywords: savedSummary.keywords ? JSON.parse(savedSummary.keywords) : [],
        transcriptSource: savedSummary.transcriptSource,
        isFavorite: savedSummary.isFavorite,
        createdAt: savedSummary.createdAt.toISOString(),
        // RAG-specific info
        confidence: summary.confidence,
        warnings: summary.warnings,
        chunksAnalyzed: chunkCount,
        processingTime: `${processingTime}s`
      },
      remaining: Math.max(0, limit - todayUsage - 1),
    });
  } catch (error) {
    console.error("[API] Summarization error:", error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to process video" },
      { status: 500 }
    );
  }
}
