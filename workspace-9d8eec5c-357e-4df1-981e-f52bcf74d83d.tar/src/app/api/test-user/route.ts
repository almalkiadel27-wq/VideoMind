import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import bcrypt from "bcryptjs";

export async function GET() {
  try {
    // Check if any users exist
    const users = await db.user.findMany({
      select: { id: true, email: true, name: true, role: true },
    });
    
    return NextResponse.json({
      userCount: users.length,
      users
    });
  } catch (error) {
    console.error("Error:", error);
    return NextResponse.json({ error: "Error" }, { status: 500 });
  }
}

export async function POST() {
  try {
    // Check if test user exists
    const existing = await db.user.findUnique({
      where: { email: "test@test.com" }
    });
    
    if (existing) {
      return NextResponse.json({
        message: "Test user already exists",
        user: { email: "test@test.com", password: "123456" }
      });
    }
    
    // Create test user
    const hashedPassword = await bcrypt.hash("123456", 10);
    const user = await db.user.create({
      data: {
        email: "test@test.com",
        password: hashedPassword,
        name: "Test User",
      },
    });
    
    // Create subscription for user
    await db.subscription.create({
      data: {
        userId: user.id,
        plan: "free",
        isActive: true,
      },
    });
    
    return NextResponse.json({
      message: "Test user created successfully!",
      user: {
        email: "test@test.com",
        password: "123456"
      }
    });
  } catch (error) {
    console.error("Error creating user:", error);
    return NextResponse.json({ error: "Error" }, { status: 500 });
  }
}
