import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const user = await db.user.findUnique({
      where: { id: session.user.id },
      include: { subscription: true },
    });

    if (!user) {
      return NextResponse.json(
        { error: "User not found" },
        { status: 404 }
      );
    }

    // Get today's usage
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const todayUsage = await db.usageRecord.count({
      where: {
        userId: user.id,
        action: "summarize",
        date: { gte: today },
      },
    });

    // Get total summaries count
    const totalSummaries = await db.videoSummary.count({
      where: { userId: user.id },
    });

    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        subscription: {
          plan: user.subscription?.plan || "free",
          isActive: user.subscription?.isActive || true,
        },
        usage: {
          todaySummaries: todayUsage,
          dailyLimit: user.subscription?.plan === "free" ? 5 : null,
          totalSummaries,
        },
      },
    });
  } catch (error) {
    console.error("Error fetching user:", error);
    return NextResponse.json(
      { error: "Failed to fetch user data" },
      { status: 500 }
    );
  }
}
