import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "VideoMind - AI Video Summarizer",
  description: "VideoMind - Summarize any YouTube video using AI. Get main ideas, key points, and timeline in your preferred language. Fast, accurate, and elegant.",
  keywords: ["AI", "Video Summarizer", "YouTube", "Summary", "AI Tools", "Video Analysis"],
  authors: [{ name: "VideoMind Team" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "VideoMind - AI Video Summarizer",
    description: "Summarize any video with AI - In your language",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "VideoMind - AI Video Summarizer",
    description: "Summarize any video with AI - In your language",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning className="dark">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground min-h-screen`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
