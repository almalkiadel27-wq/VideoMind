"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  signIn, 
  signOut, 
  useSession, 
  SessionProvider,
} from "next-auth/react";
import { 
  Copy, 
  Share2, 
  Trash2, 
  Star, 
  Globe, 
  Sparkles,
  LogOut,
  Check,
  Loader2,
  Clock,
  Lightbulb,
  Crown,
  User,
  Library,
  Brain,
  Shield,
  Users,
  BarChart3,
  Settings,
  Database,
  Activity,
  TrendingUp,
  Eye,
  Edit,
  Search,
  ChevronLeft,
  KeyRound,
  AlertCircle,
  Bell,
  BellRing,
  Send,
  X,
  Save,
  RefreshCw,
  PieChart,
  LineChart,
  Mail,
  Zap,
  Lock,
  Globe2,
  Calendar,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { toast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart as RechartsPie,
  Pie,
  Cell,
  BarChart,
  Bar,
  Legend,
} from "recharts";

// Types
interface VideoSummary {
  id: string;
  videoUrl: string;
  videoTitle: string | null;
  videoThumbnail: string | null;
  originalLanguage: string | null;
  summaryLanguage: string;
  mainIdea: string;
  keyPoints: string[];
  conclusion: string;
  timeline: { time: string; description: string }[] | null;
  fullSummary: string | null;
  keywords: string[];
  transcriptSource: string | null;
  isFavorite: boolean;
  createdAt: string;
}

interface UserData {
  id: string;
  email: string;
  name: string | null;
  subscription: {
    plan: string;
    isActive: boolean;
  };
  usage: {
    todaySummaries: number;
    dailyLimit: number | null;
    totalSummaries: number;
  };
}

interface AdminUser {
  id: string;
  email: string;
  name: string | null;
  role: string;
  createdAt: string;
  subscription: { plan: string; isActive: boolean } | null;
  _count: { summaries: number };
}

interface AdminStats {
  totalUsers: number;
  adminCount: number;
  regularUsers: number;
  totalSummaries: number;
  summariesToday: number;
  activeSubscriptions: number;
  premiumSubscriptions: number;
  recentUsers: number;
}

interface Notification {
  id: string;
  title: string;
  message: string;
  type: string;
  isRead: boolean;
  createdAt: string;
  user?: { name: string | null; email: string };
}

interface SystemSettings {
  siteName: string;
  siteDescription: string;
  dailyLimitFree: string;
  dailyLimitPremium: string;
  maxVideoLength: string;
  allowedDomains: string;
  maintenanceMode: string;
  registrationEnabled: string;
  emailNotificationsEnabled: string;
}

interface ReportData {
  period: string;
  chartData: { date: string; summaries: number; newUsers: number }[];
  planDistribution: { free: number; monthly: number; yearly: number };
  languageDistribution: Record<string, number>;
  topUsers: { id: string; name: string | null; email: string; _count: { summaries: number } }[];
  totalSummariesInPeriod: number;
  totalNewUsersInPeriod: number;
}

// Language options
const LANGUAGES = [
  { code: "en", name: "English", flag: "🇺🇸" },
  { code: "ar", name: "العربية", flag: "🇸🇦" },
  { code: "es", name: "Español", flag: "🇪🇸" },
  { code: "fr", name: "Français", flag: "🇫🇷" },
  { code: "de", name: "Deutsch", flag: "🇩🇪" },
  { code: "zh", name: "中文", flag: "🇨🇳" },
  { code: "ja", name: "日本語", flag: "🇯🇵" },
  { code: "ko", name: "한국어", flag: "🇰🇷" },
  { code: "pt", name: "Português", flag: "🇧🇷" },
  { code: "ru", name: "Русский", flag: "🇷🇺" },
  { code: "it", name: "Italiano", flag: "🇮🇹" },
  { code: "hi", name: "हिन्दी", flag: "🇮🇳" },
  { code: "tr", name: "Türkçe", flag: "🇹🇷" },
  { code: "nl", name: "Nederlands", flag: "🇳🇱" },
  { code: "pl", name: "Polski", flag: "🇵🇱" },
];

// Processing steps for animation
const PROCESSING_STEPS = [
  { key: "analyzing", text: "Analyzing video..." },
  { key: "extracting", text: "Extracting content..." },
  { key: "translating", text: "Translating content..." },
  { key: "summarizing", text: "Summarizing..." },
];

// Chart colors
const CHART_COLORS = ['#FFD700', '#0A84FF', '#34C759', '#FF9500', '#AF52DE', '#FF3B30'];

// Auth Provider Component
function AuthProvider({ children }: { children: React.ReactNode }) {
  return <SessionProvider>{children}</SessionProvider>;
}

// AI Network Particles Background
function AINetworkParticles({ color = "#0A84FF", intensity = 1 }: { color?: string; intensity?: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);
    
    const particles: { x: number; y: number; vx: number; vy: number; size: number; opacity: number }[] = [];
    const particleCount = Math.floor(40 * intensity);
    
    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.3,
        vy: (Math.random() - 0.5) * 0.3,
        size: Math.random() * 2 + 1,
        opacity: Math.random() * 0.5 + 0.2,
      });
    }
    
    let animationId: number;
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      particles.forEach((p, i) => {
        p.x += p.vx;
        p.y += p.vy;
        
        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;
        
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = color.includes('#0A84FF') 
          ? `rgba(10, 132, 255, ${p.opacity * 0.4})`
          : `rgba(90, 200, 250, ${p.opacity * 0.4})`;
        ctx.fill();
        
        particles.slice(i + 1).forEach(p2 => {
          const dx = p.x - p2.x;
          const dy = p.y - p2.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          
          if (dist < 120) {
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.strokeStyle = color.includes('#0A84FF')
              ? `rgba(10, 132, 255, ${(1 - dist / 120) * 0.12})`
              : `rgba(90, 200, 250, ${(1 - dist / 120) * 0.12})`;
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        });
      });
      
      animationId = requestAnimationFrame(animate);
    };
    
    animate();
    
    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationId);
    };
  }, [color, intensity]);
  
  return (
    <canvas 
      ref={canvasRef} 
      className="absolute inset-0 pointer-events-none z-0"
      style={{ background: 'transparent' }}
    />
  );
}

// Splash Screen Component
function SplashScreen({ onComplete }: { onComplete: () => void }) {
  const [showLogo, setShowLogo] = useState(false);
  
  useEffect(() => {
    const timer1 = setTimeout(() => setShowLogo(true), 200);
    const timer2 = setTimeout(onComplete, 2500);
    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
    };
  }, [onComplete]);
  
  return (
    <motion.div 
      className="fixed inset-0 z-50 flex items-center justify-center overflow-hidden"
      style={{ 
        background: 'linear-gradient(180deg, #2C2C30 0%, #1C1C1E 100%)'
      }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      <AINetworkParticles color="#0A84FF" intensity={1.2} />
      
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ 
          opacity: showLogo ? 1 : 0, 
          scale: showLogo ? 1 : 0.8 
        }}
        transition={{ 
          type: "spring", 
          stiffness: 150, 
          damping: 12,
          delay: 0.1
        }}
        className="relative z-10 text-center"
      >
        <motion.h1 
          className="text-5xl font-bold tracking-tight"
          style={{
            color: '#FFD700',
            textShadow: '0 0 40px rgba(255, 215, 0, 0.5), 0 0 80px rgba(255, 215, 0, 0.3)'
          }}
        >
          VideoMind
        </motion.h1>
        
        <motion.p 
          className="text-[#8E8E93] mt-4 text-sm tracking-widest uppercase"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
        >
          AI-Powered Video Intelligence
        </motion.p>
        
        <motion.div 
          className="flex justify-center gap-2 mt-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
        >
          {[0, 1, 2].map((i) => (
            <motion.div
              key={i}
              className="w-2 h-2 rounded-full"
              style={{ backgroundColor: '#FFD700' }}
              animate={{
                y: [0, -8, 0],
                opacity: [0.3, 1, 0.3]
              }}
              transition={{
                duration: 0.8,
                repeat: Infinity,
                delay: i * 0.15
              }}
            />
          ))}
        </motion.div>
      </motion.div>
    </motion.div>
  );
}

// Admin Login Form
function AdminLoginForm({ onBack }: { onBack: () => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    try {
      const response = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || "Login failed");
        return;
      }

      // Store admin session in localStorage
      localStorage.setItem("adminUser", JSON.stringify(data.user));
      window.location.reload();
    } catch {
      setError("An error occurred. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full"
    >
      <div className="text-center mb-8">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center"
          style={{ 
            background: 'linear-gradient(135deg, #FFD700 0%, #FFA500 100%)',
            boxShadow: '0 0 30px rgba(255, 215, 0, 0.4)'
          }}
        >
          <Shield className="w-8 h-8 text-[#1C1C1E]" />
        </motion.div>
        <motion.h1 
          className="text-3xl font-bold"
          style={{
            color: '#FFD700',
            textShadow: '0 0 30px rgba(255, 215, 0, 0.4)'
          }}
        >
          لوحة المدير
        </motion.h1>
        <p className="text-[#8E8E93] mt-2 text-sm">تسجيل دخول المدير</p>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="rounded-[14px] p-6 mx-auto"
        style={{
          width: '80%',
          maxWidth: '400px',
          background: 'linear-gradient(180deg, #2C2C30 0%, #1C1C1E 100%)',
          boxShadow: 'rgba(0, 0, 0, 0.3) 0px 8px 24px'
        }}
      >
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-2">
            <Label htmlFor="admin-email" className="text-white text-sm font-medium">البريد الإلكتروني</Label>
            <Input
              id="admin-email"
              type="email"
              placeholder="admin@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="h-12 bg-[#2C2C30] border-none text-white placeholder:text-[#8E8E93] focus:ring-2 focus:ring-[#FFD700] rounded-[12px]"
              style={{ boxShadow: 'rgba(0, 0, 0, 0.3) 0px 4px 6px' }}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="admin-password" className="text-white text-sm font-medium">كلمة المرور</Label>
            <Input
              id="admin-password"
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="h-12 bg-[#2C2C30] border-none text-white placeholder:text-[#8E8E93] focus:ring-2 focus:ring-[#FFD700] rounded-[12px]"
              style={{ boxShadow: 'rgba(0, 0, 0, 0.3) 0px 4px 6px' }}
              required
            />
          </div>

          {error && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-red-400 text-sm text-center"
            >
              {error}
            </motion.p>
          )}

          <Button
            type="submit"
            disabled={isLoading}
            className="w-full h-12 font-semibold rounded-[14px] transition-all duration-300 hover:scale-[1.02]"
            style={{
              background: 'linear-gradient(135deg, #FFD700 0%, #FFA500 100%)',
              color: '#1C1C1E',
              boxShadow: isLoading ? 'none' : '0 0 20px rgba(255, 215, 0, 0.3)'
            }}
          >
            {isLoading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              "تسجيل الدخول كمدير"
            )}
          </Button>
        </form>

        <div className="mt-6 text-center">
          <button
            type="button"
            onClick={onBack}
            className="text-white text-sm hover:text-[#FFD700] transition-colors flex items-center justify-center gap-2 mx-auto"
          >
            <ChevronLeft className="w-4 h-4" />
            العودة لتسجيل المستخدم
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

// Admin Setup Form (First time setup)
function AdminSetupForm({ onComplete }: { onComplete: () => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [secretKey, setSecretKey] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    if (password.length < 6) {
      setError("كلمة المرور يجب أن تكون 6 أحرف على الأقل");
      setIsLoading(false);
      return;
    }

    try {
      const response = await fetch("/api/admin/setup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, name, secretKey }),
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || "Setup failed");
        return;
      }

      setSuccess(true);
      setTimeout(() => {
        onComplete();
      }, 2000);
    } catch {
      setError("An error occurred. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  if (success) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full text-center"
      >
        <div
          className="rounded-[14px] p-8 mx-auto"
          style={{
            width: '80%',
            maxWidth: '400px',
            background: 'linear-gradient(180deg, #2C2C30 0%, #1C1C1E 100%)'
          }}
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200 }}
            className="w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center"
            style={{ 
              background: 'linear-gradient(135deg, #34C759 0%, #30D158 100%)',
              boxShadow: '0 0 30px rgba(52, 199, 89, 0.4)'
            }}
          >
            <Check className="w-8 h-8 text-white" />
          </motion.div>
          <h2 className="text-xl font-semibold text-white mb-2">
            تم إنشاء المدير!
          </h2>
          <p className="text-[#8E8E93]">جاري التحويل لتسجيل الدخول...</p>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full"
    >
      <div className="text-center mb-8">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center"
          style={{ 
            background: 'linear-gradient(135deg, #FFD700 0%, #FFA500 100%)',
            boxShadow: '0 0 30px rgba(255, 215, 0, 0.4)'
          }}
        >
          <KeyRound className="w-8 h-8 text-[#1C1C1E]" />
        </motion.div>
        <motion.h1 
          className="text-3xl font-bold"
          style={{
            color: '#FFD700',
            textShadow: '0 0 30px rgba(255, 215, 0, 0.4)'
          }}
        >
          Admin Setup
        </motion.h1>
        <p className="text-[#8E8E93] mt-2 text-sm">إنشاء حساب المدير الأول</p>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="rounded-[14px] p-6 mx-auto"
        style={{
          width: '80%',
          maxWidth: '400px',
          background: 'linear-gradient(180deg, #2C2C30 0%, #1C1C1E 100%)',
          boxShadow: 'rgba(0, 0, 0, 0.3) 0px 8px 24px'
        }}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="setup-name" className="text-white text-sm font-medium">Name</Label>
            <Input
              id="setup-name"
              type="text"
              placeholder="Admin Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="h-12 bg-[#2C2C30] border-none text-white placeholder:text-[#8E8E93] focus:ring-2 focus:ring-[#FFD700] rounded-[12px]"
              style={{ boxShadow: 'rgba(0, 0, 0, 0.3) 0px 4px 6px' }}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="setup-email" className="text-white text-sm font-medium">Email</Label>
            <Input
              id="setup-email"
              type="email"
              placeholder="admin@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="h-12 bg-[#2C2C30] border-none text-white placeholder:text-[#8E8E93] focus:ring-2 focus:ring-[#FFD700] rounded-[12px]"
              style={{ boxShadow: 'rgba(0, 0, 0, 0.3) 0px 4px 6px' }}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="setup-password" className="text-white text-sm font-medium">Password</Label>
            <Input
              id="setup-password"
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="h-12 bg-[#2C2C30] border-none text-white placeholder:text-[#8E8E93] focus:ring-2 focus:ring-[#FFD700] rounded-[12px]"
              style={{ boxShadow: 'rgba(0, 0, 0, 0.3) 0px 4px 6px' }}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="setup-secret" className="text-white text-sm font-medium">Secret Key</Label>
            <Input
              id="setup-secret"
              type="password"
              placeholder="Enter setup key"
              value={secretKey}
              onChange={(e) => setSecretKey(e.target.value)}
              className="h-12 bg-[#2C2C30] border-none text-white placeholder:text-[#8E8E93] focus:ring-2 focus:ring-[#FFD700] rounded-[12px]"
              style={{ boxShadow: 'rgba(0, 0, 0, 0.3) 0px 4px 6px' }}
              required
            />
            <p className="text-[#8E8E93] text-xs">Default key: admin-setup-2024</p>
          </div>

          {error && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-red-400 text-sm text-center"
            >
              {error}
            </motion.p>
          )}

          <Button
            type="submit"
            disabled={isLoading}
            className="w-full h-12 font-semibold rounded-[14px] transition-all duration-300 hover:scale-[1.02]"
            style={{
              background: 'linear-gradient(135deg, #FFD700 0%, #FFA500 100%)',
              color: '#1C1C1E',
              boxShadow: isLoading ? 'none' : '0 0 20px rgba(255, 215, 0, 0.3)'
            }}
          >
            {isLoading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              "Create Admin Account"
            )}
          </Button>
        </form>
      </motion.div>
    </motion.div>
  );
}

// Admin Dashboard
function AdminDashboard({ adminUser, onLogout }: { adminUser: { id: string; email: string; name: string; role: string }; onLogout: () => void }) {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [recentSummaries, setRecentSummaries] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");
  const [searchQuery, setSearchQuery] = useState("");
  const [page, setPage] = useState(1);
  
  // New state for features
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [settings, setSettings] = useState<SystemSettings | null>(null);
  const [reportData, setReportData] = useState<ReportData | null>(null);
  const [reportPeriod, setReportPeriod] = useState("7d");
  
  // Dialogs
  const [showNotificationDialog, setShowNotificationDialog] = useState(false);
  const [showSettingsDialog, setShowSettingsDialog] = useState(false);
  const [notificationTitle, setNotificationTitle] = useState("");
  const [notificationMessage, setNotificationMessage] = useState("");
  const [notificationType, setNotificationType] = useState("info");
  const [broadcastMode, setBroadcastMode] = useState(true);
  const [selectedUserId, setSelectedUserId] = useState("");

  const fetchStats = useCallback(async () => {
    try {
      const response = await fetch("/api/admin/stats");
      if (response.ok) {
        const data = await response.json();
        setStats(data.stats);
        setRecentSummaries(data.recentSummaries);
      }
    } catch (error) {
      console.error("Error fetching stats:", error);
    }
  }, []);

  const fetchUsers = useCallback(async () => {
    try {
      const response = await fetch(`/api/admin/users?page=${page}&search=${searchQuery}`);
      if (response.ok) {
        const data = await response.json();
        setUsers(data.users);
      }
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  }, [page, searchQuery]);

  const fetchNotifications = useCallback(async () => {
    try {
      const response = await fetch("/api/admin/notifications");
      if (response.ok) {
        const data = await response.json();
        setNotifications(data.notifications);
        setUnreadCount(data.unreadCount);
      }
    } catch (error) {
      console.error("Error fetching notifications:", error);
    }
  }, []);

  const fetchSettings = useCallback(async () => {
    try {
      const response = await fetch("/api/admin/settings");
      if (response.ok) {
        const data = await response.json();
        setSettings(data.settings);
      }
    } catch (error) {
      console.error("Error fetching settings:", error);
    }
  }, []);

  const fetchReports = useCallback(async () => {
    try {
      const response = await fetch(`/api/admin/reports?period=${reportPeriod}`);
      if (response.ok) {
        const data = await response.json();
        setReportData(data);
      }
    } catch (error) {
      console.error("Error fetching reports:", error);
    }
  }, [reportPeriod]);

  useEffect(() => {
    let isMounted = true;
    
    const loadData = async () => {
      await Promise.all([fetchStats(), fetchUsers(), fetchNotifications(), fetchSettings(), fetchReports()]);
      if (isMounted) {
        setIsLoading(false);
      }
    };
    
    loadData();
    
    return () => {
      isMounted = false;
    };
  }, [fetchStats, fetchUsers, fetchNotifications, fetchSettings, fetchReports]);

  useEffect(() => {
    let isMounted = true;
    
    const loadReports = async () => {
      try {
        const response = await fetch(`/api/admin/reports?period=${reportPeriod}`);
        if (response.ok && isMounted) {
          const data = await response.json();
          setReportData(data);
        }
      } catch (error) {
        console.error("Error fetching reports:", error);
      }
    };
    
    loadReports();
    
    return () => {
      isMounted = false;
    };
  }, [reportPeriod]);

  const handleRoleChange = async (userId: string, newRole: string) => {
    try {
      const response = await fetch("/api/admin/users", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, role: newRole }),
      });

      if (response.ok) {
        fetchUsers();
        toast({
          title: "Success",
          description: "User role updated successfully",
        });
      }
    } catch (error) {
      console.error("Error updating user:", error);
    }
  };

  const handleDeleteUser = async (userId: string) => {
    try {
      const response = await fetch(`/api/admin/users?userId=${userId}`, {
        method: "DELETE",
      });

      if (response.ok) {
        fetchUsers();
        fetchStats();
        toast({
          title: "Success",
          description: "User deleted successfully",
        });
      }
    } catch (error) {
      console.error("Error deleting user:", error);
    }
  };

  const handleSendNotification = async () => {
    if (!notificationTitle || !notificationMessage) {
      toast({
        title: "Error",
        description: "Title and message are required",
        variant: "destructive",
      });
      return;
    }

    try {
      const response = await fetch("/api/admin/notifications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: notificationTitle,
          message: notificationMessage,
          type: notificationType,
          broadcast: broadcastMode,
          userId: broadcastMode ? undefined : selectedUserId,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        toast({
          title: "Success",
          description: data.message,
        });
        setShowNotificationDialog(false);
        setNotificationTitle("");
        setNotificationMessage("");
        fetchNotifications();
      }
    } catch (error) {
      console.error("Error sending notification:", error);
    }
  };

  const handleUpdateSettings = async (newSettings: Partial<SystemSettings>) => {
    try {
      const response = await fetch("/api/admin/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ settings: { ...settings, ...newSettings } }),
      });

      if (response.ok) {
        toast({
          title: "Success",
          description: "Settings updated successfully",
        });
        fetchSettings();
      }
    } catch (error) {
      console.error("Error updating settings:", error);
    }
  };

  const handleMarkAllRead = async () => {
    try {
      await fetch("/api/admin/notifications", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ markAllRead: true }),
      });
      fetchNotifications();
    } catch (error) {
      console.error("Error marking notifications as read:", error);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: '#1C1C1E' }}>
        <Loader2 className="w-8 h-8 animate-spin text-[#FFD700]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ background: 'linear-gradient(180deg, #2C2C30 0%, #1C1C1E 100%)' }}>
      {/* Header */}
      <header className="border-b border-[#3A3A3C] px-6 py-4 sticky top-0 z-50" style={{ background: 'rgba(28, 28, 30, 0.95)', backdropFilter: 'blur(10px)' }}>
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #FFD700 0%, #FFA500 100%)' }}>
              <Shield className="w-5 h-5 text-[#1C1C1E]" />
            </div>
            <div>
              <h1 className="text-white font-bold text-lg">لوحة التحكم</h1>
              <p className="text-[#8E8E93] text-sm">{adminUser.email}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            {/* Notifications Badge */}
            <Button
              onClick={() => setActiveTab("notifications")}
              className="rounded-[10px] relative"
              style={{ background: '#2C2C30', color: '#FFFFFF' }}
            >
              {unreadCount > 0 ? (
                <BellRing className="w-4 h-4" />
              ) : (
                <Bell className="w-4 h-4" />
              )}
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full text-xs flex items-center justify-center" style={{ background: '#FF3B30', color: '#fff' }}>
                  {unreadCount}
                </span>
              )}
            </Button>
            
            <Button
              onClick={onLogout}
              className="rounded-[10px] text-sm"
              style={{ background: '#2C2C30', color: '#FFFFFF' }}
            >
              <LogOut className="w-4 h-4 mr-2" />
              تسجيل الخروج
            </Button>
          </div>
        </div>
      </header>

      {/* Content */}
      <div className="max-w-7xl mx-auto p-6">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6 bg-[#2C2C30] rounded-[12px] p-1 flex flex-wrap">
            <TabsTrigger value="overview" className="rounded-[10px] data-[state=active]:bg-[#FFD700] data-[state=active]:text-[#1C1C1E]">
              <BarChart3 className="w-4 h-4 mr-2" />
              نظرة عامة
            </TabsTrigger>
            <TabsTrigger value="users" className="rounded-[10px] data-[state=active]:bg-[#FFD700] data-[state=active]:text-[#1C1C1E]">
              <Users className="w-4 h-4 mr-2" />
              المستخدمين
            </TabsTrigger>
            <TabsTrigger value="notifications" className="rounded-[10px] data-[state=active]:bg-[#FFD700] data-[state=active]:text-[#1C1C1E]">
              <Bell className="w-4 h-4 mr-2" />
              الإشعارات
            </TabsTrigger>
            <TabsTrigger value="reports" className="rounded-[10px] data-[state=active]:bg-[#FFD700] data-[state=active]:text-[#1C1C1E]">
              <LineChart className="w-4 h-4 mr-2" />
              التقارير
            </TabsTrigger>
            <TabsTrigger value="settings" className="rounded-[10px] data-[state=active]:bg-[#FFD700] data-[state=active]:text-[#1C1C1E]">
              <Settings className="w-4 h-4 mr-2" />
              الإعدادات
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview">
            {stats && (
              <>
                {/* Stats Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 }}
                  >
                    <Card className="rounded-[14px] border-0" style={{ background: '#2C2C30' }}>
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-[#8E8E93] text-sm">إجمالي المستخدمين</p>
                            <p className="text-3xl font-bold text-white">{stats.totalUsers}</p>
                          </div>
                          <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #0A84FF 0%, #5AC8FA 100%)' }}>
                            <Users className="w-6 h-6 text-white" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                  >
                    <Card className="rounded-[14px] border-0" style={{ background: '#2C2C30' }}>
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-[#8E8E93] text-sm">إجمالي الملخصات</p>
                            <p className="text-3xl font-bold text-white">{stats.totalSummaries}</p>
                          </div>
                          <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #FFD700 0%, #FFA500 100%)' }}>
                            <Database className="w-6 h-6 text-[#1C1C1E]" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                  >
                    <Card className="rounded-[14px] border-0" style={{ background: '#2C2C30' }}>
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-[#8E8E93] text-sm">المستخدمين المميزين</p>
                            <p className="text-3xl font-bold text-white">{stats.premiumSubscriptions}</p>
                          </div>
                          <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #34C759 0%, #30D158 100%)' }}>
                            <Crown className="w-6 h-6 text-white" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 }}
                  >
                    <Card className="rounded-[14px] border-0" style={{ background: '#2C2C30' }}>
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-[#8E8E93] text-sm">ملخصات اليوم</p>
                            <p className="text-3xl font-bold text-white">{stats.summariesToday}</p>
                          </div>
                          <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #FF9500 0%, #FF6B00 100%)' }}>
                            <TrendingUp className="w-6 h-6 text-white" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                </div>

                {/* Quick Stats */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <Card className="rounded-[14px] border-0" style={{ background: '#2C2C30' }}>
                    <CardContent className="p-6 text-center">
                      <p className="text-[#8E8E93] text-sm mb-2">مستخدمين جدد (7 أيام)</p>
                      <p className="text-2xl font-bold" style={{ color: '#FFD700' }}>{stats.recentUsers}</p>
                    </CardContent>
                  </Card>
                  <Card className="rounded-[14px] border-0" style={{ background: '#2C2C30' }}>
                    <CardContent className="p-6 text-center">
                      <p className="text-[#8E8E93] text-sm mb-2">حسابات المديرين</p>
                      <p className="text-2xl font-bold text-white">{stats.adminCount}</p>
                    </CardContent>
                  </Card>
                  <Card className="rounded-[14px] border-0" style={{ background: '#2C2C30' }}>
                    <CardContent className="p-6 text-center">
                      <p className="text-[#8E8E93] text-sm mb-2">المستخدمين العاديين</p>
                      <p className="text-2xl font-bold text-white">{stats.regularUsers}</p>
                    </CardContent>
                  </Card>
                </div>
              </>
            )}

            {/* Recent Activity */}
            <Card className="rounded-[14px] border-0" style={{ background: '#2C2C30' }}>
              <CardHeader>
                <CardTitle className="text-white">آخر الملخصات</CardTitle>
              </CardHeader>
              <CardContent>
                {recentSummaries.length > 0 ? (
                  <div className="space-y-3 max-h-80 overflow-y-auto">
                    {recentSummaries.map((summary) => (
                      <div key={summary.id} className="flex items-center gap-4 p-3 rounded-[12px]" style={{ background: '#1C1C1E' }}>
                        <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: '#3A3A3C' }}>
                          <Database className="w-5 h-5 text-[#8E8E93]" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-white text-sm truncate">{summary.videoTitle || "Video Summary"}</p>
                          <p className="text-[#8E8E93] text-xs">
                            بواسطة {summary.user?.name || summary.user?.email || "غير معروف"}
                          </p>
                        </div>
                        <p className="text-[#8E8E93] text-xs">
                          {new Date(summary.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-[#8E8E93] text-center py-8">No recent summaries</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users">
            <Card className="rounded-[14px] border-0" style={{ background: '#2C2C30' }}>
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <CardTitle className="text-white">إدارة المستخدمين</CardTitle>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8E8E93]" />
                    <Input
                      placeholder="بحث المستخدمين..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10 h-10 w-full md:w-64 bg-[#1C1C1E] border-none text-white placeholder:text-[#8E8E93] rounded-[10px]"
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-[#3A3A3C] hover:bg-transparent">
                        <TableHead className="text-[#8E8E93]">User</TableHead>
                        <TableHead className="text-[#8E8E93]">Email</TableHead>
                        <TableHead className="text-[#8E8E93]">الدور</TableHead>
                        <TableHead className="text-[#8E8E93]">Plan</TableHead>
                        <TableHead className="text-[#8E8E93]">Summaries</TableHead>
                        <TableHead className="text-[#8E8E93]">Joined</TableHead>
                        <TableHead className="text-[#8E8E93]">الإجراءات</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users.map((user) => (
                        <TableRow key={user.id} className="border-[#3A3A3C]">
                          <TableCell className="text-white">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: '#3A3A3C' }}>
                                {user.role === "admin" ? (
                                  <Shield className="w-4 h-4 text-[#FFD700]" />
                                ) : (
                                  <User className="w-4 h-4 text-[#8E8E93]" />
                                )}
                              </div>
                              <span>{user.name || "No name"}</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-[#8E8E93]">{user.email}</TableCell>
                          <TableCell>
                            <Badge 
                              className="rounded-lg"
                              style={{ 
                                background: user.role === "admin" 
                                  ? 'linear-gradient(135deg, #FFD700 0%, #FFA500 100%)'
                                  : '#3A3A3C',
                                color: user.role === "admin" ? '#1C1C1E' : '#FFFFFF'
                              }}
                            >
                              {user.role}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge 
                              className="rounded-lg"
                              style={{ 
                                background: user.subscription?.plan === "monthly" || user.subscription?.plan === "yearly"
                                  ? 'linear-gradient(135deg, #34C759 0%, #30D158 100%)'
                                  : '#3A3A3C',
                                color: '#FFFFFF'
                              }}
                            >
                              {user.subscription?.plan || "free"}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-white">{user._count?.summaries || 0}</TableCell>
                          <TableCell className="text-[#8E8E93]">
                            {new Date(user.createdAt).toLocaleDateString()}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Button
                                size="sm"
                                className="rounded-[8px] h-8"
                                style={{ background: '#3A3A3C', color: '#FFFFFF' }}
                                onClick={() => handleRoleChange(user.id, user.role === "admin" ? "user" : "admin")}
                                disabled={user.id === adminUser.id}
                              >
                                {user.role === "admin" ? "Demote" : "Promote"}
                              </Button>
                              <Button
                                size="sm"
                                className="rounded-[8px] h-8"
                                style={{ background: '#0A84FF', color: '#FFFFFF' }}
                                onClick={() => {
                                  setSelectedUserId(user.id);
                                  setBroadcastMode(false);
                                  setShowNotificationDialog(true);
                                }}
                              >
                                <Mail className="w-4 h-4" />
                              </Button>
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button
                                    size="sm"
                                    className="rounded-[8px] h-8 bg-red-500/20 text-red-400 hover:bg-red-500/30"
                                    disabled={user.id === adminUser.id}
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent style={{ background: '#2C2C30', border: 'none' }}>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle className="text-white">حذف المستخدم</AlertDialogTitle>
                                    <AlertDialogDescription className="text-[#8E8E93]">
                                      Are you sure you want to delete this user? This action cannot be undone.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel className="bg-[#1C1C1E] text-white border-none">Cancel</AlertDialogCancel>
                                    <AlertDialogAction
                                      className="bg-red-500 text-white"
                                      onClick={() => handleDeleteUser(user.id)}
                                    >
                                      Delete
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                {users.length === 0 && (
                  <p className="text-[#8E8E93] text-center py-8">No users found</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notifications Tab */}
          <TabsContent value="notifications">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Send Notification */}
              <Card className="rounded-[14px] border-0" style={{ background: '#2C2C30' }}>
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Send className="w-5 h-5" />
                    إرسال إشعار
                  </CardTitle>
                  <CardDescription className="text-[#8E8E93]">
                    إرسال إشعارات للمستخدمين
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label className="text-white text-sm">إرسال لجميع المستخدمين</Label>
                    <Switch
                      checked={broadcastMode}
                      onCheckedChange={setBroadcastMode}
                    />
                  </div>
                  
                  {!broadcastMode && (
                    <Select value={selectedUserId} onValueChange={setSelectedUserId}>
                      <SelectTrigger className="bg-[#1C1C1E] border-none text-white">
                        <SelectValue placeholder="اختر المستخدم" />
                      </SelectTrigger>
                      <SelectContent style={{ background: '#2C2C30', border: 'none' }}>
                        {users.map((user) => (
                          <SelectItem key={user.id} value={user.id} className="text-white focus:bg-[#3A3A3C]">
                            {user.name || user.email}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}
                  
                  <Input
                    placeholder="عنوان الإشعار"
                    value={notificationTitle}
                    onChange={(e) => setNotificationTitle(e.target.value)}
                    className="bg-[#1C1C1E] border-none text-white"
                  />
                  
                  <Textarea
                    placeholder="نص الإشعار..."
                    value={notificationMessage}
                    onChange={(e) => setNotificationMessage(e.target.value)}
                    className="bg-[#1C1C1E] border-none text-white min-h-[100px]"
                  />
                  
                  <Select value={notificationType} onValueChange={setNotificationType}>
                    <SelectTrigger className="bg-[#1C1C1E] border-none text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent style={{ background: '#2C2C30', border: 'none' }}>
                      <SelectItem value="info" className="text-white focus:bg-[#3A3A3C]">ℹ️ معلومات</SelectItem>
                      <SelectItem value="success" className="text-white focus:bg-[#3A3A3C]">✅ نجاح</SelectItem>
                      <SelectItem value="warning" className="text-white focus:bg-[#3A3A3C]">⚠️ تحذير</SelectItem>
                      <SelectItem value="error" className="text-white focus:bg-[#3A3A3C]">❌ خطأ</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Button
                    onClick={handleSendNotification}
                    className="w-full rounded-[12px]"
                    style={{ background: 'linear-gradient(135deg, #0A84FF 0%, #5AC8FA 100%)' }}
                  >
                    <Send className="w-4 h-4 mr-2" />
                    إرسال الإشعار
                  </Button>
                </CardContent>
              </Card>

              {/* Notifications List */}
              <Card className="rounded-[14px] border-0 lg:col-span-2" style={{ background: '#2C2C30' }}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-white flex items-center gap-2">
                      <Bell className="w-5 h-5" />
                      آخر الإشعارات
                      {unreadCount > 0 && (
                        <Badge style={{ background: '#FF3B30' }}>{unreadCount} غير مقروء</Badge>
                      )}
                    </CardTitle>
                    {unreadCount > 0 && (
                      <Button
                        size="sm"
                        onClick={handleMarkAllRead}
                        className="rounded-[8px]"
                        style={{ background: '#3A3A3C', color: '#FFFFFF' }}
                      >
                        تحديد الكل كمقروء
                      </Button>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {notifications.length > 0 ? (
                      notifications.map((notification) => (
                        <div
                          key={notification.id}
                          className={`p-4 rounded-[12px] ${!notification.isRead ? 'border-l-4 border-[#FFD700]' : ''}`}
                          style={{ background: '#1C1C1E' }}
                        >
                          <div className="flex items-start justify-between">
                            <div>
                              <div className="flex items-center gap-2 mb-1">
                                <Badge
                                  className="rounded-lg text-xs"
                                  style={{
                                    background: notification.type === 'success' ? '#34C759' :
                                      notification.type === 'warning' ? '#FF9500' :
                                      notification.type === 'error' ? '#FF3B30' : '#0A84FF'
                                  }}
                                >
                                  {notification.type}
                                </Badge>
                                <span className="text-white font-medium">{notification.title}</span>
                              </div>
                              <p className="text-[#8E8E93] text-sm">{notification.message}</p>
                              {notification.user && (
                                <p className="text-[#8E8E93] text-xs mt-1">To: {notification.user.email}</p>
                              )}
                              <p className="text-[#8E8E93] text-xs mt-1">
                                {new Date(notification.createdAt).toLocaleString()}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-[#8E8E93] text-center py-8">لا توجد إشعارات بعد</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Reports Tab */}
          <TabsContent value="reports">
            <div className="space-y-6">
              {/* Period Selector */}
              <div className="flex items-center gap-3">
                <Label className="text-white">الفترة:</Label>
                <Select value={reportPeriod} onValueChange={setReportPeriod}>
                  <SelectTrigger className="w-40 bg-[#2C2C30] border-none text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent style={{ background: '#2C2C30', border: 'none' }}>
                    <SelectItem value="7d" className="text-white focus:bg-[#3A3A3C]">آخر 7 أيام</SelectItem>
                    <SelectItem value="30d" className="text-white focus:bg-[#3A3A3C]">آخر 30 يوم</SelectItem>
                    <SelectItem value="90d" className="text-white focus:bg-[#3A3A3C]">آخر 90 يوم</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {reportData && (
                <>
                  {/* Summary Stats */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Card className="rounded-[14px] border-0" style={{ background: '#2C2C30' }}>
                      <CardContent className="p-6 text-center">
                        <Activity className="w-8 h-8 mx-auto mb-2 text-[#FFD700]" />
                        <p className="text-3xl font-bold text-white">{reportData.totalSummariesInPeriod}</p>
                        <p className="text-[#8E8E93]">ملخصات في الفترة</p>
                      </CardContent>
                    </Card>
                    <Card className="rounded-[14px] border-0" style={{ background: '#2C2C30' }}>
                      <CardContent className="p-6 text-center">
                        <Users className="w-8 h-8 mx-auto mb-2 text-[#34C759]" />
                        <p className="text-3xl font-bold text-white">{reportData.totalNewUsersInPeriod}</p>
                        <p className="text-[#8E8E93]">مستخدمين جدد في الفترة</p>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Activity Chart */}
                  <Card className="rounded-[14px] border-0" style={{ background: '#2C2C30' }}>
                    <CardHeader>
                      <CardTitle className="text-white flex items-center gap-2">
                        <LineChart className="w-5 h-5" />
                        نظرة عامة على النشاط
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                          <AreaChart data={reportData.chartData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#3A3A3C" />
                            <XAxis dataKey="date" stroke="#8E8E93" tick={{ fontSize: 10 }} />
                            <YAxis stroke="#8E8E93" />
                            <Tooltip
                              contentStyle={{
                                background: '#2C2C30',
                                border: 'none',
                                borderRadius: '8px',
                                color: '#fff'
                              }}
                            />
                            <Area
                              type="monotone"
                              dataKey="summaries"
                              stroke="#FFD700"
                              fill="#FFD700"
                              fillOpacity={0.2}
                              name="Summaries"
                            />
                            <Area
                              type="monotone"
                              dataKey="newUsers"
                              stroke="#0A84FF"
                              fill="#0A84FF"
                              fillOpacity={0.2}
                              name="New Users"
                            />
                          </AreaChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Plan Distribution */}
                    <Card className="rounded-[14px] border-0" style={{ background: '#2C2C30' }}>
                      <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                          <PieChart className="w-5 h-5" />
                          Subscription Plans
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="h-48">
                          <ResponsiveContainer width="100%" height="100%">
                            <RechartsPie>
                              <Pie
                                data={[
                                  { name: 'Free', value: reportData.planDistribution.free, fill: '#8E8E93' },
                                  { name: 'Monthly', value: reportData.planDistribution.monthly, fill: '#FFD700' },
                                  { name: 'Yearly', value: reportData.planDistribution.yearly, fill: '#34C759' },
                                ]}
                                cx="50%"
                                cy="50%"
                                innerRadius={40}
                                outerRadius={70}
                                dataKey="value"
                                label={({ name, value }) => `${name}: ${value}`}
                              />
                              <Tooltip
                                contentStyle={{
                                  background: '#2C2C30',
                                  border: 'none',
                                  borderRadius: '8px',
                                  color: '#fff'
                                }}
                              />
                            </RechartsPie>
                          </ResponsiveContainer>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Top Users */}
                    <Card className="rounded-[14px] border-0" style={{ background: '#2C2C30' }}>
                      <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                          <Crown className="w-5 h-5" />
                          Top Active Users
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3 max-h-48 overflow-y-auto">
                          {reportData.topUsers.map((user, index) => (
                            <div key={user.id} className="flex items-center gap-3 p-2 rounded-[8px]" style={{ background: '#1C1C1E' }}>
                              <div
                                className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold"
                                style={{
                                  background: index === 0 ? '#FFD700' : index === 1 ? '#C0C0C0' : index === 2 ? '#CD7F32' : '#3A3A3C',
                                  color: '#1C1C1E'
                                }}
                              >
                                {index + 1}
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-white text-sm truncate">{user.name || user.email}</p>
                              </div>
                              <Badge className="rounded-lg" style={{ background: '#3A3A3C' }}>
                                {user._count.summaries} summaries
                              </Badge>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Language Distribution */}
                  <Card className="rounded-[14px] border-0" style={{ background: '#2C2C30' }}>
                    <CardHeader>
                      <CardTitle className="text-white flex items-center gap-2">
                        <Globe className="w-5 h-5" />
                        Summary Languages
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="h-48">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={Object.entries(reportData.languageDistribution)
                              .map(([lang, count]) => ({
                                language: LANGUAGES.find(l => l.code === lang)?.name || lang,
                                count
                              }))
                              .sort((a, b) => b.count - a.count)
                              .slice(0, 8)
                            }
                          >
                            <CartesianGrid strokeDasharray="3 3" stroke="#3A3A3C" />
                            <XAxis dataKey="language" stroke="#8E8E93" tick={{ fontSize: 10 }} />
                            <YAxis stroke="#8E8E93" />
                            <Tooltip
                              contentStyle={{
                                background: '#2C2C30',
                                border: 'none',
                                borderRadius: '8px',
                                color: '#fff'
                              }}
                            />
                            <Bar dataKey="count" fill="#FFD700" radius={[4, 4, 0, 0]} />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}
            </div>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings">
            {settings && (
              <div className="space-y-6">
                {/* Site Settings */}
                <Card className="rounded-[14px] border-0" style={{ background: '#2C2C30' }}>
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Globe2 className="w-5 h-5" />
                      Site Settings
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label className="text-white text-sm mb-2 block">Site Name</Label>
                        <Input
                          value={settings.siteName}
                          onChange={(e) => setSettings({ ...settings, siteName: e.target.value })}
                          className="bg-[#1C1C1E] border-none text-white"
                        />
                      </div>
                      <div>
                        <Label className="text-white text-sm mb-2 block">Site Description</Label>
                        <Input
                          value={settings.siteDescription}
                          onChange={(e) => setSettings({ ...settings, siteDescription: e.target.value })}
                          className="bg-[#1C1C1E] border-none text-white"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Usage Limits */}
                <Card className="rounded-[14px] border-0" style={{ background: '#2C2C30' }}>
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Zap className="w-5 h-5" />
                      Usage Limits
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <Label className="text-white text-sm mb-2 block">Daily Limit (Free Users)</Label>
                        <Input
                          type="number"
                          value={settings.dailyLimitFree}
                          onChange={(e) => setSettings({ ...settings, dailyLimitFree: e.target.value })}
                          className="bg-[#1C1C1E] border-none text-white"
                        />
                      </div>
                      <div>
                        <Label className="text-white text-sm mb-2 block">Daily Limit (Premium)</Label>
                        <Input
                          type="number"
                          value={settings.dailyLimitPremium}
                          onChange={(e) => setSettings({ ...settings, dailyLimitPremium: e.target.value })}
                          className="bg-[#1C1C1E] border-none text-white"
                        />
                      </div>
                      <div>
                        <Label className="text-white text-sm mb-2 block">Max Video Length (minutes)</Label>
                        <Input
                          type="number"
                          value={settings.maxVideoLength}
                          onChange={(e) => setSettings({ ...settings, maxVideoLength: e.target.value })}
                          className="bg-[#1C1C1E] border-none text-white"
                        />
                      </div>
                    </div>
                    <div>
                      <Label className="text-white text-sm mb-2 block">Allowed Video Domains</Label>
                      <Input
                        value={settings.allowedDomains}
                        onChange={(e) => setSettings({ ...settings, allowedDomains: e.target.value })}
                        className="bg-[#1C1C1E] border-none text-white"
                      />
                      <p className="text-[#8E8E93] text-xs mt-1">Comma-separated list of allowed domains</p>
                    </div>
                  </CardContent>
                </Card>

                {/* Feature Toggles */}
                <Card className="rounded-[14px] border-0" style={{ background: '#2C2C30' }}>
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Lock className="w-5 h-5" />
                      Feature Toggles
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between p-4 rounded-[12px]" style={{ background: '#1C1C1E' }}>
                      <div>
                        <p className="text-white font-medium">Maintenance Mode</p>
                        <p className="text-[#8E8E93] text-sm">Disable site for all users except admins</p>
                      </div>
                      <Switch
                        checked={settings.maintenanceMode === "true"}
                        onCheckedChange={(checked) => handleUpdateSettings({ maintenanceMode: checked ? "true" : "false" })}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between p-4 rounded-[12px]" style={{ background: '#1C1C1E' }}>
                      <div>
                        <p className="text-white font-medium">User Registration</p>
                        <p className="text-[#8E8E93] text-sm">Allow new users to register</p>
                      </div>
                      <Switch
                        checked={settings.registrationEnabled === "true"}
                        onCheckedChange={(checked) => handleUpdateSettings({ registrationEnabled: checked ? "true" : "false" })}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between p-4 rounded-[12px]" style={{ background: '#1C1C1E' }}>
                      <div>
                        <p className="text-white font-medium">Email Notifications</p>
                        <p className="text-[#8E8E93] text-sm">Send email notifications to users</p>
                      </div>
                      <Switch
                        checked={settings.emailNotificationsEnabled === "true"}
                        onCheckedChange={(checked) => handleUpdateSettings({ emailNotificationsEnabled: checked ? "true" : "false" })}
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Save Button */}
                <Button
                  onClick={() => handleUpdateSettings(settings)}
                  className="w-full h-12 rounded-[14px]"
                  style={{ background: 'linear-gradient(135deg, #FFD700 0%, #FFA500 100%)', color: '#1C1C1E' }}
                >
                  <Save className="w-4 h-4 mr-2" />
                  Save All Settings
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

// Login Form Component (User)
function LoginForm({ onToggleForm, onAdminClick }: { onToggleForm: () => void; onAdminClick: () => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    try {
      const result = await signIn("credentials", {
        email,
        password,
        redirect: false,
      });

      if (result?.error) {
        setError("Invalid email or password");
      }
    } catch {
      setError("An error occurred. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full"
    >
      <div className="text-center mb-8">
        <motion.h1 
          className="text-3xl font-bold"
          style={{
            color: '#FFD700',
            textShadow: '0 0 30px rgba(255, 215, 0, 0.4)'
          }}
        >
          VideoMind
        </motion.h1>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="rounded-[14px] p-6 mx-auto"
        style={{
          width: '80%',
          maxWidth: '400px',
          background: 'linear-gradient(180deg, #2C2C30 0%, #1C1C1E 100%)',
          boxShadow: 'rgba(0, 0, 0, 0.3) 0px 8px 24px'
        }}
      >
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-2">
            <Label htmlFor="email" className="text-white text-sm font-medium">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="your@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="h-12 bg-[#2C2C30] border-none text-white placeholder:text-[#8E8E93] focus:ring-2 focus:ring-[#0A84FF] rounded-[12px]"
              style={{ boxShadow: 'rgba(0, 0, 0, 0.3) 0px 4px 6px' }}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="password" className="text-white text-sm font-medium">Password</Label>
            <Input
              id="password"
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="h-12 bg-[#2C2C30] border-none text-white placeholder:text-[#8E8E93] focus:ring-2 focus:ring-[#0A84FF] rounded-[12px]"
              style={{ boxShadow: 'rgba(0, 0, 0, 0.3) 0px 4px 6px' }}
              required
            />
          </div>

          {error && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-red-400 text-sm text-center"
            >
              {error}
            </motion.p>
          )}

          <Button
            type="submit"
            disabled={isLoading}
            className="w-full h-12 font-semibold rounded-[14px] transition-all duration-300 hover:scale-[1.02]"
            style={{
              background: 'linear-gradient(135deg, #0A84FF 0%, #5AC8FA 100%)',
              boxShadow: isLoading ? 'none' : '0 0 20px rgba(10, 132, 255, 0.3)'
            }}
          >
            {isLoading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              "Login"
            )}
          </Button>
        </form>

        <div className="mt-6 flex flex-col items-center gap-3">
          <button
            type="button"
            onClick={onToggleForm}
            className="text-white text-sm hover:text-[#FFD700] transition-colors"
            style={{ textShadow: '0 0 10px rgba(255, 215, 0, 0.3)' }}
          >
            Create Account
          </button>
          <button
            type="button"
            onClick={onAdminClick}
            className="text-[#8E8E93] text-xs hover:text-[#FFD700] transition-colors flex items-center gap-1"
          >
            <Shield className="w-3 h-3" />
            Admin Panel
          </button>
        </div>
      </motion.div>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="text-center mt-8 text-sm px-8 mx-auto"
        style={{ 
          color: '#FFD700',
          maxWidth: '400px',
          lineHeight: '1.8'
        }}
        dir="rtl"
      >
        مرحبًا بك في عالم الذكاء والفخامة – حيث تتحول الفيديوهات الطويلة إلى معرفة سريعة وراقية.
      </motion.p>
    </motion.div>
  );
}

// Signup Form Component
function SignupForm({ onToggleForm }: { onToggleForm: () => void }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (password !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    if (password.length < 6) {
      setError("Password must be at least 6 characters");
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, name }),
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || "Registration failed");
        return;
      }

      setSuccess(true);
      
      setTimeout(() => {
        signIn("credentials", {
          email,
          password,
          redirect: false,
        });
      }, 1500);
    } catch {
      setError("An error occurred. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  if (success) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full text-center"
      >
        <div
          className="rounded-[14px] p-8 mx-auto"
          style={{
            width: '80%',
            maxWidth: '400px',
            background: 'linear-gradient(180deg, #2C2C30 0%, #1C1C1E 100%)'
          }}
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200 }}
            className="w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center"
            style={{ 
              background: 'linear-gradient(135deg, #34C759 0%, #30D158 100%)',
              boxShadow: '0 0 30px rgba(52, 199, 89, 0.4)'
            }}
          >
            <Check className="w-8 h-8 text-white" />
          </motion.div>
          <h2 className="text-xl font-semibold text-white mb-2">
            Account Created!
          </h2>
          <p className="text-[#8E8E93]">Signing you in...</p>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full"
    >
      <div className="text-center mb-8">
        <motion.h1 
          className="text-3xl font-bold"
          style={{
            color: '#FFD700',
            textShadow: '0 0 30px rgba(255, 215, 0, 0.4)'
          }}
        >
          VideoMind
        </motion.h1>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="rounded-[14px] p-6 mx-auto"
        style={{
          width: '80%',
          maxWidth: '400px',
          background: 'linear-gradient(180deg, #2C2C30 0%, #1C1C1E 100%)',
          boxShadow: 'rgba(0, 0, 0, 0.3) 0px 8px 24px'
        }}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name" className="text-white text-sm font-medium">Name (optional)</Label>
            <Input
              id="name"
              type="text"
              placeholder="Your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="h-12 bg-[#2C2C30] border-none text-white placeholder:text-[#8E8E93] focus:ring-2 focus:ring-[#0A84FF] rounded-[12px]"
              style={{ boxShadow: 'rgba(0, 0, 0, 0.3) 0px 4px 6px' }}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="signup-email" className="text-white text-sm font-medium">Email</Label>
            <Input
              id="signup-email"
              type="email"
              placeholder="your@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="h-12 bg-[#2C2C30] border-none text-white placeholder:text-[#8E8E93] focus:ring-2 focus:ring-[#0A84FF] rounded-[12px]"
              style={{ boxShadow: 'rgba(0, 0, 0, 0.3) 0px 4px 6px' }}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="signup-password" className="text-white text-sm font-medium">Password</Label>
            <Input
              id="signup-password"
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="h-12 bg-[#2C2C30] border-none text-white placeholder:text-[#8E8E93] focus:ring-2 focus:ring-[#0A84FF] rounded-[12px]"
              style={{ boxShadow: 'rgba(0, 0, 0, 0.3) 0px 4px 6px' }}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="confirm-password" className="text-white text-sm font-medium">Confirm Password</Label>
            <Input
              id="confirm-password"
              type="password"
              placeholder="••••••••"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="h-12 bg-[#2C2C30] border-none text-white placeholder:text-[#8E8E93] focus:ring-2 focus:ring-[#0A84FF] rounded-[12px]"
              style={{ boxShadow: 'rgba(0, 0, 0, 0.3) 0px 4px 6px' }}
              required
            />
          </div>

          {error && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-red-400 text-sm text-center"
            >
              {error}
            </motion.p>
          )}

          <Button
            type="submit"
            disabled={isLoading}
            className="w-full h-12 font-semibold rounded-[14px] transition-all duration-300 hover:scale-[1.02]"
            style={{
              background: 'linear-gradient(135deg, #0A84FF 0%, #5AC8FA 100%)',
              boxShadow: isLoading ? 'none' : '0 0 20px rgba(10, 132, 255, 0.3)'
            }}
          >
            {isLoading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              "Create Account"
            )}
          </Button>
        </form>

        <div className="mt-6 text-center">
          <button
            onClick={onToggleForm}
            className="text-white text-sm hover:text-[#FFD700] transition-colors"
          >
            Already have an account? Sign in
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

// Processing Animation Component
function ProcessingAnimation({ currentText }: { currentText: string }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="flex flex-col items-center justify-center py-20 relative"
    >
      <AINetworkParticles color="#5AC8FA" intensity={0.6} />
      
      <div className="relative z-10">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
          className="w-[120px] h-[120px] rounded-full flex items-center justify-center"
          style={{
            border: '3px solid transparent',
            borderTopColor: '#0A84FF',
            borderRightColor: '#0A84FF',
            boxShadow: '0 0 30px rgba(10, 132, 255, 0.4)'
          }}
        />
        
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.div
            animate={{ scale: [1, 1.1, 1] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          >
            <Brain className="w-10 h-10" style={{ color: '#0A84FF' }} />
          </motion.div>
        </div>
      </div>

      <motion.div
        key={currentText}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mt-8 z-10"
      >
        <p className="text-white text-lg font-medium">{currentText}</p>
      </motion.div>
    </motion.div>
  );
}

// Summary Display Component
function SummaryDisplay({ 
  summary, 
  onCopy, 
  onShare, 
  onToggleFavorite,
  onDelete 
}: { 
  summary: VideoSummary;
  onCopy: () => void;
  onShare: () => void;
  onToggleFavorite: () => void;
  onDelete: () => void;
}) {
  const lang = LANGUAGES.find(l => l.code === summary.summaryLanguage);
  const isRTL = ["ar", "he", "fa"].includes(summary.summaryLanguage);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
      dir={isRTL ? "rtl" : "ltr"}
    >
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-[14px] overflow-hidden"
        style={{
          background: '#2C2C30',
          boxShadow: 'rgba(0, 0, 0, 0.3) 0px 4px 12px'
        }}
      >
        <div className="flex flex-col md:flex-row">
          {summary.videoThumbnail && (
            <div className="md:w-72 h-48 md:h-auto relative">
              <img
                src={summary.videoThumbnail}
                alt={summary.videoTitle || "Video thumbnail"}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            </div>
          )}
          <div className="flex-1 p-5">
            <h2 className="text-lg font-bold text-white mb-2">
              {summary.videoTitle || "Video Summary"}
            </h2>
            <div className="flex items-center gap-2 text-[#8E8E93] text-sm">
              <Globe className="w-4 h-4" />
              <span>{lang?.flag} {lang?.name}</span>
            </div>
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.1 }}
        className="rounded-[12px] p-5"
        style={{
          background: '#FFD700',
          boxShadow: '0 0 30px rgba(255, 215, 0, 0.2)'
        }}
      >
        <div className="flex items-center gap-3 mb-3">
          <Lightbulb className="w-5 h-5 text-[#1C1C1E]" />
          <h3 className="text-[#1C1C1E] font-bold">Main Idea</h3>
        </div>
        <p className="text-[#1C1C1E] text-lg leading-relaxed font-medium">{summary.mainIdea}</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="space-y-3"
      >
        {summary.keyPoints.map((point, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 + index * 0.1 }}
            className="rounded-[12px] p-4"
            style={{
              background: '#2C2C30',
              boxShadow: 'rgba(0, 0, 0, 0.2) 0px 2px 8px'
            }}
          >
            <p className="text-white">{point}</p>
          </motion.div>
        ))}
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="rounded-[12px] p-5"
        style={{
          background: '#2C2C30',
          boxShadow: 'rgba(0, 0, 0, 0.2) 0px 2px 8px'
        }}
      >
        <div className="flex items-center gap-3 mb-3">
          <Sparkles className="w-5 h-5 text-[#5AC8FA]" />
          <h3 className="text-white font-bold">Quick Summary</h3>
        </div>
        <p className="text-white leading-relaxed">{summary.conclusion}</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
        className="flex flex-wrap justify-center gap-3 pt-4"
      >
        <Button
          onClick={onCopy}
          className="rounded-[12px] px-6 transition-all duration-300 hover:shadow-[0_0_15px_rgba(90,200,250,0.3)]"
          style={{ background: '#2C2C30', color: '#FFFFFF' }}
        >
          <Copy className="w-4 h-4 mr-2" />
          Copy
        </Button>
        <Button
          onClick={onShare}
          className="rounded-[12px] px-6 transition-all duration-300 hover:shadow-[0_0_15px_rgba(90,200,250,0.3)]"
          style={{ background: '#2C2C30', color: '#FFFFFF' }}
        >
          <Share2 className="w-4 h-4 mr-2" />
          Share
        </Button>
        <Button
          onClick={onToggleFavorite}
          className="rounded-[12px] px-6 transition-all duration-300 hover:shadow-[0_0_15px_rgba(90,200,250,0.3)]"
          style={{ background: '#2C2C30', color: '#FFFFFF' }}
        >
          <Star className={`w-4 h-4 mr-2 ${summary.isFavorite ? "fill-current text-[#FFD700]" : ""}`} />
          Save
        </Button>
        <Button
          onClick={onDelete}
          className="rounded-[12px] px-6 text-red-400 hover:text-red-300 transition-all duration-300"
          style={{ background: '#2C2C30' }}
        >
          <Trash2 className="w-4 h-4 mr-2" />
          Delete
        </Button>
      </motion.div>
    </motion.div>
  );
}

// Library Card Component
function LibraryCard({ 
  summary, 
  onSelect, 
}: { 
  summary: VideoSummary;
  onSelect: () => void;
}) {
  const lang = LANGUAGES.find(l => l.code === summary.summaryLanguage);
  const date = new Date(summary.createdAt).toLocaleDateString();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.3 }}
      className="group cursor-pointer"
    >
      <div 
        className="rounded-[14px] overflow-hidden"
        style={{
          background: '#2C2C30',
          boxShadow: 'rgba(0, 0, 0, 0.2) 0px 4px 12px'
        }}
        onClick={onSelect}
      >
        <div className="flex">
          {summary.videoThumbnail && (
            <div className="w-28 h-28 flex-shrink-0 relative">
              <img
                src={summary.videoThumbnail}
                alt={summary.videoTitle || "Video thumbnail"}
                className="w-full h-full object-cover"
              />
            </div>
          )}
          <div className="flex-1 p-4">
            <h3 className="font-semibold text-white line-clamp-2 text-sm mb-1">
              {summary.videoTitle || "Video Summary"}
            </h3>
            <p className="text-[#8E8E93] text-xs mb-2">
              {lang?.flag} {lang?.name} • {date}
            </p>
            <p className="text-[#8E8E93] text-xs line-clamp-2">
              {summary.mainIdea}
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// Main App Component
function MainApp() {
  const { data: session, status } = useSession();
  const [showSplash, setShowSplash] = useState(true);
  const [isSignUp, setIsSignUp] = useState(false);
  const [activeTab, setActiveTab] = useState<"summarize" | "library">("summarize");
  const [videoUrl, setVideoUrl] = useState("");
  const [selectedLanguage, setSelectedLanguage] = useState("en");
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingText, setProcessingText] = useState("");
  const [currentSummary, setCurrentSummary] = useState<VideoSummary | null>(null);
  const [summaries, setSummaries] = useState<VideoSummary[]>([]);
  const [userData, setUserData] = useState<UserData | null>(null);
  const [selectedLibrarySummary, setSelectedLibrarySummary] = useState<VideoSummary | null>(null);
  
  // Admin states
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [showAdminSetup, setShowAdminSetup] = useState(false);
  const [adminUser, setAdminUser] = useState<{ id: string; email: string; name: string; role: string } | null>(null);

  // Check for admin session on mount
  useEffect(() => {
    const storedAdmin = localStorage.getItem("adminUser");
    if (storedAdmin) {
      try {
        setAdminUser(JSON.parse(storedAdmin));
      } catch {
        localStorage.removeItem("adminUser");
      }
    }
  }, []);

  // Check if admin exists (for setup)
  useEffect(() => {
    if (showAdminLogin) {
      fetch("/api/admin/stats")
        .then(res => res.json())
        .then(data => {
          if (data.error && data.error.includes("No admin")) {
            setShowAdminLogin(false);
            setShowAdminSetup(true);
          }
        })
        .catch(() => {});
    }
  }, [showAdminLogin]);

  const fetchUserData = useCallback(async () => {
    try {
      const response = await fetch("/api/user");
      if (response.ok) {
        const data = await response.json();
        setUserData(data.user);
      }
    } catch (error) {
      console.error("Error fetching user data:", error);
    }
  }, []);

  const fetchSummaries = useCallback(async () => {
    try {
      const response = await fetch("/api/summaries");
      if (response.ok) {
        const data = await response.json();
        setSummaries(data.summaries);
      }
    } catch (error) {
      console.error("Error fetching summaries:", error);
    }
  }, []);

  useEffect(() => {
    if (session?.user) {
      fetchUserData();
      fetchSummaries();
    }
  }, [session, fetchUserData, fetchSummaries]);

  const handleSummarize = async () => {
    if (!videoUrl.trim()) {
      toast({
        title: "Error",
        description: "Please enter a video URL",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    setProcessingText(PROCESSING_STEPS[0].text);

    const stepInterval = setInterval(() => {
      setProcessingText((prev) => {
        const currentIndex = PROCESSING_STEPS.findIndex(s => s.text === prev);
        const nextIndex = (currentIndex + 1) % PROCESSING_STEPS.length;
        return PROCESSING_STEPS[nextIndex].text;
      });
    }, 2000);

    try {
      const response = await fetch("/api/summarize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ videoUrl, targetLanguage: selectedLanguage }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to summarize");
      }

      setCurrentSummary(data.summary);
      fetchSummaries();
      fetchUserData();
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to summarize video",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
      clearInterval(stepInterval);
    }
  };

  const handleCopy = () => {
    if (currentSummary) {
      const text = `${currentSummary.mainIdea}\n\n${currentSummary.keyPoints.join('\n')}\n\n${currentSummary.conclusion}`;
      navigator.clipboard.writeText(text);
      toast({
        title: "Copied!",
        description: "Summary copied to clipboard",
      });
    }
  };

  const handleShare = () => {
    if (navigator.share && currentSummary) {
      navigator.share({
        title: currentSummary.videoTitle || "Video Summary",
        text: `${currentSummary.mainIdea}\n\n${currentSummary.keyPoints.join('\n')}`,
      });
    }
  };

  const handleToggleFavorite = async () => {
    if (!currentSummary) return;
    try {
      await fetch("/api/summaries/favorite", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ summaryId: currentSummary.id }),
      });
      setCurrentSummary({ ...currentSummary, isFavorite: !currentSummary.isFavorite });
      fetchSummaries();
    } catch (error) {
      console.error("Error toggling favorite:", error);
    }
  };

  const handleDelete = async () => {
    if (!currentSummary) return;
    try {
      await fetch(`/api/summaries?summaryId=${currentSummary.id}`, {
        method: "DELETE",
      });
      setCurrentSummary(null);
      fetchSummaries();
      fetchUserData();
    } catch (error) {
      console.error("Error deleting summary:", error);
    }
  };

  const handleAdminLogout = () => {
    localStorage.removeItem("adminUser");
    setAdminUser(null);
  };

  // Show admin dashboard if admin is logged in
  if (adminUser) {
    return <AdminDashboard adminUser={adminUser} onLogout={handleAdminLogout} />;
  }

  // Show splash screen
  if (showSplash) {
    return (
      <motion.div
        initial={{ opacity: 1 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <SplashScreen onComplete={() => setShowSplash(false)} />
      </motion.div>
    );
  }

  // Show admin setup
  if (showAdminSetup) {
    return (
      <div 
        className="min-h-screen flex items-center justify-center overflow-hidden relative"
        style={{ background: 'linear-gradient(180deg, #2C2C30 0%, #1C1C1E 100%)' }}
      >
        <AINetworkParticles color="#FFD700" intensity={0.8} />
        <div className="relative z-10 w-full px-4">
          <AdminSetupForm onComplete={() => {
            setShowAdminSetup(false);
            setShowAdminLogin(true);
          }} />
        </div>
      </div>
    );
  }

  // Show admin login
  if (showAdminLogin) {
    return (
      <div 
        className="min-h-screen flex items-center justify-center overflow-hidden relative"
        style={{ background: 'linear-gradient(180deg, #2C2C30 0%, #1C1C1E 100%)' }}
      >
        <AINetworkParticles color="#FFD700" intensity={0.8} />
        <div className="relative z-10 w-full px-4">
          <AdminLoginForm onBack={() => setShowAdminLogin(false)} />
        </div>
      </div>
    );
  }

  // Show login/signup if not authenticated
  if (status === "unauthenticated" || !session) {
    return (
      <div 
        className="min-h-screen flex items-center justify-center overflow-hidden relative"
        style={{ background: 'linear-gradient(180deg, #2C2C30 0%, #1C1C1E 100%)' }}
      >
        <AINetworkParticles color="#0A84FF" intensity={0.8} />
        <div className="relative z-10 w-full px-4">
          <AnimatePresence mode="wait">
            {isSignUp ? (
              <SignupForm key="signup" onToggleForm={() => setIsSignUp(false)} />
            ) : (
              <LoginForm 
                key="login" 
                onToggleForm={() => setIsSignUp(true)} 
                onAdminClick={() => setShowAdminLogin(true)}
              />
            )}
          </AnimatePresence>
        </div>
      </div>
    );
  }

  // Main app content
  return (
    <div 
      className="min-h-screen"
      style={{ background: 'linear-gradient(180deg, #2C2C30 0%, #1C1C1E 100%)' }}
    >
      {/* Header */}
      <header className="border-b border-[#3A3A3C] px-4 py-4">
        <div className="max-w-3xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #FFD700 0%, #FFA500 100%)' }}>
              <span className="text-[#1C1C1E] font-bold text-lg">V</span>
            </div>
            <div>
              <h1 className="text-white font-bold">VideoMind</h1>
              {userData?.subscription?.plan === "monthly" && (
                <Badge className="rounded-lg text-xs" style={{ background: 'linear-gradient(135deg, #FFD700 0%, #FFA500 100%)', color: '#1C1C1E' }}>
                  Premium
                </Badge>
              )}
            </div>
          </div>
          <Button
            onClick={() => signOut()}
            className="rounded-[10px]"
            style={{ background: '#2C2C30', color: '#FFFFFF' }}
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-3xl mx-auto p-4 pb-24">
        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "summarize" | "library")}>
          <TabsList className="mb-6 w-full bg-[#2C2C30] rounded-[12px] p-1">
            <TabsTrigger value="summarize" className="flex-1 rounded-[10px] data-[state=active]:bg-[#FFD700] data-[state=active]:text-[#1C1C1E]">
              Summarize
            </TabsTrigger>
            <TabsTrigger value="library" className="flex-1 rounded-[10px] data-[state=active]:bg-[#FFD700] data-[state=active]:text-[#1C1C1E]">
              <Library className="w-4 h-4 mr-2" />
              Library ({summaries.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="summarize">
            {isProcessing ? (
              <ProcessingAnimation currentText={processingText} />
            ) : currentSummary ? (
              <SummaryDisplay
                summary={currentSummary}
                onCopy={handleCopy}
                onShare={handleShare}
                onToggleFavorite={handleToggleFavorite}
                onDelete={handleDelete}
              />
            ) : (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                {/* Video URL Input */}
                <div
                  className="rounded-[14px] p-6"
                  style={{
                    background: '#2C2C30',
                    boxShadow: 'rgba(0, 0, 0, 0.3) 0px 4px 12px'
                  }}
                >
                  <Label className="text-white text-sm font-medium mb-3 block">
                    Video URL
                    <span className="text-[#8E8E93] text-xs mr-2">— يدعم جميع المنصات</span>
                  </Label>
                  <Input
                    type="url"
                    placeholder="Paste any video URL (YouTube, TikTok, Vimeo, Instagram...)"
                    value={videoUrl}
                    onChange={(e) => setVideoUrl(e.target.value)}
                    className="h-14 bg-[#1C1C1E] border-none text-white placeholder:text-[#8E8E93] focus:ring-2 focus:ring-[#0A84FF] rounded-[12px] text-lg"
                    style={{ boxShadow: 'rgba(0, 0, 0, 0.2) 0px 2px 6px' }}
                  />
                  <p className="text-[#8E8E93] text-xs mt-2">
                    ✅ YouTube • TikTok • Vimeo • Instagram • Facebook • Twitter/X • Twitch • Dailymotion • Reddit • والمزيد
                  </p>

                  <Label className="text-white text-sm font-medium mb-3 mt-5 block">
                    Summary Language
                  </Label>
                  <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                    <SelectTrigger className="h-12 bg-[#1C1C1E] border-none text-white rounded-[12px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent style={{ background: '#2C2C30', border: 'none' }}>
                      {LANGUAGES.map((lang) => (
                        <SelectItem key={lang.code} value={lang.code} className="text-white focus:bg-[#3A3A3C]">
                          {lang.flag} {lang.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Button
                    onClick={handleSummarize}
                    className="w-full h-14 mt-6 font-semibold rounded-[14px] transition-all duration-300 hover:scale-[1.02]"
                    style={{
                      background: 'linear-gradient(135deg, #0A84FF 0%, #5AC8FA 100%)',
                      boxShadow: '0 0 20px rgba(10, 132, 255, 0.3)'
                    }}
                  >
                    Summarize Video
                  </Button>
                </div>

                {/* Usage Stats */}
                {userData && (
                  <div
                    className="rounded-[14px] p-6"
                    style={{
                      background: '#2C2C30',
                      boxShadow: 'rgba(0, 0, 0, 0.3) 0px 4px 12px'
                    }}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-[#8E8E93] text-sm">Today&apos;s Usage</span>
                      <span className="text-white font-medium">
                        {userData.usage.todaySummaries} / {userData.usage.dailyLimit || "∞"}
                      </span>
                    </div>
                    {userData.usage.dailyLimit && (
                      <Progress value={(userData.usage.todaySummaries / userData.usage.dailyLimit) * 100} />
                    )}
                    <p className="text-[#8E8E93] text-xs mt-2">
                      Total summaries: {userData.usage.totalSummaries}
                    </p>
                  </div>
                )}
              </motion.div>
            )}
          </TabsContent>

          <TabsContent value="library">
            {selectedLibrarySummary ? (
              <div>
                <Button
                  onClick={() => setSelectedLibrarySummary(null)}
                  className="mb-4 rounded-[10px]"
                  style={{ background: '#2C2C30', color: '#FFFFFF' }}
                >
                  <ChevronLeft className="w-4 h-4 mr-2" />
                  Back to Library
                </Button>
                <SummaryDisplay
                  summary={selectedLibrarySummary}
                  onCopy={() => {
                    const text = `${selectedLibrarySummary.mainIdea}\n\n${selectedLibrarySummary.keyPoints.join('\n')}`;
                    navigator.clipboard.writeText(text);
                    toast({ title: "Copied!", description: "Summary copied to clipboard" });
                  }}
                  onShare={() => {
                    if (navigator.share) {
                      navigator.share({
                        title: selectedLibrarySummary.videoTitle || "Video Summary",
                        text: selectedLibrarySummary.mainIdea,
                      });
                    }
                  }}
                  onToggleFavorite={async () => {
                    await fetch("/api/summaries/favorite", {
                      method: "POST",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({ summaryId: selectedLibrarySummary.id }),
                    });
                    fetchSummaries();
                    setSelectedLibrarySummary({ ...selectedLibrarySummary, isFavorite: !selectedLibrarySummary.isFavorite });
                  }}
                  onDelete={async () => {
                    await fetch(`/api/summaries?summaryId=${selectedLibrarySummary.id}`, { method: "DELETE" });
                    fetchSummaries();
                    setSelectedLibrarySummary(null);
                  }}
                />
              </div>
            ) : (
              <div className="space-y-4">
                {summaries.length === 0 ? (
                  <div
                    className="rounded-[14px] p-12 text-center"
                    style={{ background: '#2C2C30' }}
                  >
                    <Library className="w-12 h-12 text-[#8E8E93] mx-auto mb-4" />
                    <p className="text-[#8E8E93]">No summaries yet</p>
                    <p className="text-[#8E8E93] text-sm mt-1">
                      Start by summarizing a video
                    </p>
                  </div>
                ) : (
                  summaries.map((summary) => (
                    <LibraryCard
                      key={summary.id}
                      summary={summary}
                      onSelect={() => setSelectedLibrarySummary(summary)}
                    />
                  ))
                )}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

// Export
export default function Home() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
