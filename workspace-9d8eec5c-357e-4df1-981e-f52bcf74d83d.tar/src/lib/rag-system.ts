/**
 * RAG System for Video Summarization
 * 
 * This system implements Retrieval Augmented Generation to produce
 * accurate video summaries without hallucination.
 * 
 * Pipeline:
 * 1. Extract Transcript → Get video content
 * 2. Chunk Text → Split into 500-800 word segments
 * 3. Store Chunks → Save to database
 * 4. Retrieve Relevant → Find important chunks
 * 5. Generate Summary → Create accurate summary
 * 6. Verify Summary → Check accuracy
 */

import ZAI from 'z-ai-web-dev-sdk';
import { db } from './db';

// ============================================
// Types
// ============================================

interface VideoInfo {
  platform: string;
  videoId: string | null;
  thumbnail: string | null;
}

interface TextChunk {
  id?: string;
  videoUrl: string;
  chunkIndex: number;
  content: string;
  wordCount: number;
  timestamp?: string;
}

interface TranscriptResult {
  text: string;
  source: 'youtube' | 'web_search' | 'asr' | 'cache';
  language?: string;
}

interface RetrievedChunk {
  chunk: TextChunk;
  relevanceScore: number;
}

interface SummaryResult {
  videoTitle: string;
  mainIdea: string;
  keyPoints: string[];
  conclusion: string;
  fullSummary: string;
  keywords: string[];
  originalLanguage: string;
  confidence: 'high' | 'medium' | 'low';
  warnings?: string[];
}

// ============================================
// Stage 1: Extract Video Info
// ============================================

export function extractVideoInfo(url: string): VideoInfo {
  try {
    const urlObj = new URL(url);
    const hostname = urlObj.hostname.replace('www.', '');
    
    // YouTube
    if (hostname.includes('youtube.com') || hostname === 'youtu.be') {
      let videoId = null;
      if (hostname === 'youtu.be') {
        videoId = urlObj.pathname.slice(1).split('?')[0];
      } else if (urlObj.pathname.includes('/shorts/')) {
        videoId = urlObj.pathname.split('/shorts/')[1]?.split('?')[0];
      } else if (urlObj.pathname.includes('/embed/')) {
        videoId = urlObj.pathname.split('/embed/')[1]?.split('?')[0];
      } else {
        videoId = urlObj.searchParams.get('v');
      }
      return {
        platform: 'YouTube',
        videoId,
        thumbnail: videoId ? `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg` : null
      };
    }
    
    // Other platforms
    if (hostname.includes('vimeo.com')) return { platform: 'Vimeo', videoId: null, thumbnail: null };
    if (hostname.includes('tiktok.com')) return { platform: 'TikTok', videoId: null, thumbnail: null };
    if (hostname.includes('instagram.com')) return { platform: 'Instagram', videoId: null, thumbnail: null };
    if (hostname.includes('facebook.com') || hostname.includes('fb.watch')) return { platform: 'Facebook', videoId: null, thumbnail: null };
    if (hostname.includes('twitter.com') || hostname.includes('x.com')) return { platform: 'Twitter/X', videoId: null, thumbnail: null };
    
    return { platform: 'Video', videoId: null, thumbnail: null };
  } catch {
    return { platform: 'Video', videoId: null, thumbnail: null };
  }
}

// ============================================
// Stage 2: Extract Transcript
// ============================================

async function getTranscriptFromCache(videoUrl: string): Promise<TranscriptResult | null> {
  const ragProcessing = await db.rAGProcessing.findUnique({
    where: { videoUrl }
  });
  
  if (ragProcessing?.transcript && ragProcessing.status === 'ready') {
    return {
      text: ragProcessing.transcript,
      source: 'cache'
    };
  }
  
  return null;
}

async function searchForTranscript(
  videoInfo: VideoInfo,
  zai: Awaited<ReturnType<typeof ZAI.create>>
): Promise<TranscriptResult> {
  console.log('[RAG] Searching for video transcript...');
  
  let fullText = '';
  let videoTitle = '';
  
  // Strategy 1: Search for video transcript
  if (videoInfo.videoId) {
    const transcriptSearch = await zai.functions.invoke('web_search', {
      query: `"${videoInfo.videoId}" transcript subtitles content discussion`,
      num: 5
    });
    
    if (transcriptSearch && Array.isArray(transcriptSearch)) {
      const validResults = transcriptSearch.filter((r: { snippet: string }) => {
        const lower = (r.snippet || '').toLowerCase();
        // Filter out tool/extension results
        return !lower.includes('chrome extension') &&
               !lower.includes('transcript tool') &&
               !lower.includes('summarize any') &&
               r.snippet && r.snippet.length > 50;
      });
      
      if (validResults.length > 0) {
        fullText = validResults.map((r: { name: string; snippet: string }) => 
          `${r.name}: ${r.snippet}`
        ).join('\n\n');
        
        if (validResults[0]?.name) {
          videoTitle = validResults[0].name;
        }
      }
    }
  }
  
  // Strategy 2: Search for video topic
  if (fullText.length < 200) {
    const topicSearch = await zai.functions.invoke('web_search', {
      query: `youtube watch?v=${videoInfo.videoId} video about`,
      num: 3
    });
    
    if (topicSearch && Array.isArray(topicSearch) && topicSearch.length > 0) {
      const result = topicSearch[0];
      if (result.snippet) {
        fullText = result.snippet;
        videoTitle = result.name || videoTitle;
      }
    }
  }
  
  return {
    text: fullText,
    source: 'web_search'
  };
}

// ============================================
// Stage 3: Chunk Text (500-800 words)
// ============================================

export function chunkText(text: string, maxWords: number = 600, overlap: number = 50): TextChunk[] {
  const words = text.split(/\s+/);
  const chunks: TextChunk[] = [];
  
  let currentIndex = 0;
  let chunkIndex = 0;
  
  while (currentIndex < words.length) {
    const endIndex = Math.min(currentIndex + maxWords, words.length);
    const chunkWords = words.slice(currentIndex, endIndex);
    
    // Find a good breaking point (end of sentence)
    let breakPoint = chunkWords.length;
    for (let i = chunkWords.length - 1; i > chunkWords.length * 0.7; i--) {
      if (chunkWords[i]?.match(/[.!?؟]/)) {
        breakPoint = i + 1;
        break;
      }
    }
    
    const content = chunkWords.slice(0, breakPoint).join(' ');
    
    if (content.trim().length > 0) {
      chunks.push({
        content: content.trim(),
        wordCount: breakPoint,
        chunkIndex,
        videoUrl: '' // Will be set later
      });
    }
    
    // Move forward with overlap
    currentIndex += breakPoint - overlap;
    chunkIndex++;
    
    // Safety check
    if (chunkIndex > 100) break;
  }
  
  return chunks;
}

// ============================================
// Stage 4: Store Chunks
// ============================================

async function storeChunks(videoUrl: string, chunks: TextChunk[]): Promise<void> {
  // Clear existing chunks
  await db.textChunk.deleteMany({
    where: { videoUrl }
  });
  
  // Insert new chunks
  for (const chunk of chunks) {
    await db.textChunk.create({
      data: {
        videoUrl,
        chunkIndex: chunk.chunkIndex,
        content: chunk.content,
        wordCount: chunk.wordCount
      }
    });
  }
  
  console.log(`[RAG] Stored ${chunks.length} chunks`);
}

// ============================================
// Stage 5: Retrieve Relevant Chunks
// ============================================

async function retrieveRelevantChunks(
  videoUrl: string,
  query: string,
  topK: number = 5,
  zai: Awaited<ReturnType<typeof ZAI.create>>
): Promise<RetrievedChunk[]> {
  // Get all chunks for this video
  const allChunks = await db.textChunk.findMany({
    where: { videoUrl },
    orderBy: { chunkIndex: 'asc' }
  });
  
  if (allChunks.length === 0) {
    return [];
  }
  
  // If few chunks, return all
  if (allChunks.length <= topK) {
    return allChunks.map(chunk => ({
      chunk: {
        videoUrl: chunk.videoUrl,
        chunkIndex: chunk.chunkIndex,
        content: chunk.content,
        wordCount: chunk.wordCount
      },
      relevanceScore: 1.0
    }));
  }
  
  // Use LLM to find most relevant chunks
  const chunkSummaries = allChunks.map((c, i) => `[${i}] ${c.content.substring(0, 200)}...`);
  
  const relevancePrompt = `You are a relevance scoring system. Given a query and text chunks, identify which chunks are most relevant.

Query: "${query}"

Chunks:
${chunkSummaries.join('\n\n')}

Return ONLY a JSON array of the top ${topK} most relevant chunk indices with relevance scores (0-1):
[{"index": 0, "score": 0.9}, {"index": 2, "score": 0.8}, ...]`;

  try {
    const completion = await zai.chat.completions.create({
      messages: [{ role: 'user', content: relevancePrompt }]
    });
    
    const response = completion.choices[0]?.message?.content || '';
    const jsonMatch = response.match(/\[[\s\S]*\]/);
    
    if (jsonMatch) {
      const scores = JSON.parse(jsonMatch[0]);
      
      return scores.map((s: { index: number; score: number }) => ({
        chunk: {
          videoUrl: allChunks[s.index].videoUrl,
          chunkIndex: allChunks[s.index].chunkIndex,
          content: allChunks[s.index].content,
          wordCount: allChunks[s.index].wordCount
        },
        relevanceScore: s.score
      }));
    }
  } catch (e) {
    console.log('[RAG] Relevance scoring failed, using first chunks');
  }
  
  // Fallback: return first topK chunks
  return allChunks.slice(0, topK).map(chunk => ({
    chunk: {
      videoUrl: chunk.videoUrl,
      chunkIndex: chunk.chunkIndex,
      content: chunk.content,
      wordCount: chunk.wordCount
    },
    relevanceScore: 1.0
  }));
}

// ============================================
// Stage 6: Generate Summary
// ============================================

async function generateSummary(
  chunks: RetrievedChunk[],
  targetLanguage: string,
  zai: Awaited<ReturnType<typeof ZAI.create>>
): Promise<SummaryResult> {
  
  const combinedContent = chunks.map(c => c.chunk.content).join('\n\n---\n\n');
  
  const summaryPrompt = `You are a professional content analyst. Your task is to summarize video content STRICTLY based on the provided transcript sections.

═══════════════════════════════════════════════════════════════
⚠️ CRITICAL RULES - YOU MUST FOLLOW THESE EXACTLY:
═══════════════════════════════════════════════════════════════

1. ✅ ONLY use information that EXISTS in the transcript below
2. ❌ Do NOT invent, assume, guess, or hallucinate ANY information
3. ❌ If something is NOT mentioned, do NOT include it
4. ✅ Preserve the original meaning accurately
5. ❌ Avoid generic statements or vague summaries
6. ✅ Extract the most important ideas the speaker ACTUALLY says
7. ❌ NEVER make up topics, facts, or details not in the content
8. ⚠️ If information is missing, say: "Not mentioned in the video"

═══════════════════════════════════════════════════════════════
🌍 OUTPUT LANGUAGE - VERY IMPORTANT:
═══════════════════════════════════════════════════════════════

YOU MUST WRITE YOUR ENTIRE RESPONSE IN: ${targetLanguage}

All text in the JSON values (mainIdea, keyPoints, conclusion, fullSummary, keywords) MUST be written in ${targetLanguage}.
DO NOT use English unless the target language is English.

═══════════════════════════════════════════════════════════════
📹 TRANSCRIPT SECTIONS:
═══════════════════════════════════════════════════════════════

${combinedContent.substring(0, 6000)}

═══════════════════════════════════════════════════════════════
📝 OUTPUT FORMAT:
═══════════════════════════════════════════════════════════════

Return ONLY valid JSON (no markdown, no code blocks). ALL TEXT MUST BE IN ${targetLanguage}:

{
  "videoTitle": "Title if mentioned, otherwise null",
  "mainIdea": "One clear sentence about the main idea IN ${targetLanguage}",
  "keyPoints": [
    "Important point 1 ACTUALLY mentioned - IN ${targetLanguage}",
    "Important point 2 ACTUALLY mentioned - IN ${targetLanguage}",
    "Important point 3 ACTUALLY mentioned - IN ${targetLanguage}",
    "Important point 4 ACTUALLY mentioned - IN ${targetLanguage}",
    "Important point 5 ACTUALLY mentioned - IN ${targetLanguage}"
  ],
  "conclusion": "Key takeaway from the video IN ${targetLanguage}",
  "fullSummary": "A detailed paragraph summarizing the content IN ${targetLanguage}",
  "keywords": ["keyword1", "keyword2", "keyword3", "keyword4", "keyword5"],
  "originalLanguage": "Detected language of transcript",
  "confidence": "high or medium or low",
  "warnings": ["Any warnings about incomplete information"]
}`;

  const completion = await zai.chat.completions.create({
    messages: [{ role: 'user', content: summaryPrompt }]
  });
  
  const response = completion.choices[0]?.message?.content || '';
  
  try {
    // Clean response
    let jsonStr = response.trim();
    if (jsonStr.startsWith('```json')) jsonStr = jsonStr.slice(7);
    if (jsonStr.startsWith('```')) jsonStr = jsonStr.slice(3);
    if (jsonStr.endsWith('```')) jsonStr = jsonStr.slice(0, -3);
    
    const jsonMatch = jsonStr.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]);
    }
  } catch (e) {
    console.error('[RAG] JSON parse error:', e);
  }
  
  // Fallback
  return {
    videoTitle: 'Video Summary',
    mainIdea: 'Unable to extract main idea',
    keyPoints: ['Summary generation failed'],
    conclusion: 'Please try again',
    fullSummary: combinedContent.substring(0, 500),
    keywords: [],
    originalLanguage: 'Unknown',
    confidence: 'low',
    warnings: ['Failed to parse AI response']
  };
}

// ============================================
// Stage 7: Verify Summary
// ============================================

async function verifySummary(
  summary: SummaryResult,
  chunks: RetrievedChunk[],
  zai: Awaited<ReturnType<typeof ZAI.create>>
): Promise<SummaryResult> {
  
  const originalContent = chunks.map(c => c.chunk.content).join(' ');
  
  const verifyPrompt = `You are a fact-checker. Verify if the summary accurately reflects the original transcript.

═══════════════════════════════════════════════════════════════
ORIGINAL TRANSCRIPT (excerpt):
═══════════════════════════════════════════════════════════════
${originalContent.substring(0, 3000)}

═══════════════════════════════════════════════════════════════
SUMMARY TO VERIFY:
═══════════════════════════════════════════════════════════════
Main Idea: ${summary.mainIdea}
Key Points: ${summary.keyPoints.join('; ')}
Conclusion: ${summary.conclusion}

═══════════════════════════════════════════════════════════════
VERIFICATION TASK:
═══════════════════════════════════════════════════════════════
Check for:
1. Missing information (claims not in transcript)
2. Incorrect statements (contradicts transcript)
3. Misinterpretations (wrong meaning)

Return ONLY valid JSON:
{
  "isValid": true or false,
  "issues": ["issue1", "issue2"] or [],
  "correctedMainIdea": "corrected version if needed, otherwise null",
  "correctedKeyPoints": ["corrected points"] or null,
  "correctedConclusion": "corrected version if needed, otherwise null"
}`;

  try {
    const completion = await zai.chat.completions.create({
      messages: [{ role: 'user', content: verifyPrompt }]
    });
    
    const response = completion.choices[0]?.message?.content || '';
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    
    if (jsonMatch) {
      const verification = JSON.parse(jsonMatch[0]);
      
      if (!verification.isValid) {
        // Apply corrections
        return {
          ...summary,
          mainIdea: verification.correctedMainIdea || summary.mainIdea,
          keyPoints: verification.correctedKeyPoints || summary.keyPoints,
          conclusion: verification.correctedConclusion || summary.conclusion,
          warnings: [...(summary.warnings || []), ...verification.issues]
        };
      }
    }
  } catch (e) {
    console.log('[RAG] Verification failed:', e);
  }
  
  return summary;
}

// ============================================
// Main Pipeline
// ============================================

export async function processVideoWithRAG(
  videoUrl: string,
  targetLanguage: string
): Promise<{ summary: SummaryResult; videoInfo: VideoInfo; chunkCount: number }> {
  
  console.log('[RAG] Starting pipeline for:', videoUrl);
  
  const zai = await ZAI.create();
  const videoInfo = extractVideoInfo(videoUrl);
  
  // Step 1: Check for cached transcript
  let transcriptResult = await getTranscriptFromCache(videoUrl);
  
  if (!transcriptResult) {
    // Step 2: Extract transcript
    transcriptResult = await searchForTranscript(videoInfo, zai);
    
    if (!transcriptResult.text || transcriptResult.text.length < 100) {
      throw new Error('Could not extract video content. The video may be private or unavailable.');
    }
  }
  
  console.log(`[RAG] Transcript obtained: ${transcriptResult.text.length} chars`);
  
  // Step 3: Chunk text
  const chunks = chunkText(transcriptResult.text);
  console.log(`[RAG] Created ${chunks.length} chunks`);
  
  // Step 4: Store chunks
  await storeChunks(videoUrl, chunks);
  
  // Update RAG processing state
  await db.rAGProcessing.upsert({
    where: { videoUrl },
    update: {
      transcript: transcriptResult.text,
      chunkCount: chunks.length,
      status: 'ready',
      progress: 100
    },
    create: {
      videoUrl,
      transcript: transcriptResult.text,
      chunkCount: chunks.length,
      status: 'ready',
      progress: 100
    }
  });
  
  // Step 5: Retrieve relevant chunks
  const relevantChunks = await retrieveRelevantChunks(
    videoUrl,
    'main topics key points important information',
    Math.min(chunks.length, 5),
    zai
  );
  console.log(`[RAG] Retrieved ${relevantChunks.length} relevant chunks`);
  
  // Step 6: Generate summary
  const summary = await generateSummary(relevantChunks, targetLanguage, zai);
  console.log('[RAG] Summary generated');
  
  // Step 7: Verify summary
  const verifiedSummary = await verifySummary(summary, relevantChunks, zai);
  console.log('[RAG] Summary verified');
  
  return {
    summary: verifiedSummary,
    videoInfo,
    chunkCount: chunks.length
  };
}

// Export for direct use
export { type SummaryResult, type TextChunk, type RetrievedChunk };
