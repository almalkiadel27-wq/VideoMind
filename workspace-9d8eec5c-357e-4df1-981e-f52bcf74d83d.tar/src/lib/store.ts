import { create } from "zustand";

export interface VideoSummary {
  id: string;
  videoUrl: string;
  videoTitle: string | null;
  videoThumbnail: string | null;
  originalLanguage: string | null;
  summaryLanguage: string;
  mainIdea: string;
  keyPoints: string[];
  conclusion: string;
  timeline: TimelineEvent[] | null;
  fullSummary: string | null;
  isFavorite: boolean;
  createdAt: string;
}

export interface TimelineEvent {
  time: string;
  description: string;
}

interface AppState {
  // Auth state
  isAuthenticated: boolean;
  user: { id: string; email: string; name: string | null } | null;
  
  // Video state
  currentVideoUrl: string;
  selectedLanguage: string;
  isProcessing: boolean;
  processingStep: string;
  currentSummary: VideoSummary | null;
  
  // Library state
  summaries: VideoSummary[];
  
  // UI state
  activeTab: "summarize" | "library";
  showSubscriptionModal: boolean;
  
  // Actions
  setAuthenticated: (isAuth: boolean, user?: { id: string; email: string; name: string | null } | null) => void;
  setVideoUrl: (url: string) => void;
  setSelectedLanguage: (lang: string) => void;
  setProcessing: (isProcessing: boolean, step?: string) => void;
  setCurrentSummary: (summary: VideoSummary | null) => void;
  setSummaries: (summaries: VideoSummary[]) => void;
  addSummary: (summary: VideoSummary) => void;
  removeSummary: (id: string) => void;
  toggleFavorite: (id: string) => void;
  setActiveTab: (tab: "summarize" | "library") => void;
  setShowSubscriptionModal: (show: boolean) => void;
  reset: () => void;
}

const initialState = {
  isAuthenticated: false,
  user: null,
  currentVideoUrl: "",
  selectedLanguage: "en",
  isProcessing: false,
  processingStep: "",
  currentSummary: null,
  summaries: [],
  activeTab: "summarize" as const,
  showSubscriptionModal: false,
};

export const useAppStore = create<AppState>((set) => ({
  ...initialState,
  
  setAuthenticated: (isAuth, user = null) => set({ isAuthenticated: isAuth, user }),
  
  setVideoUrl: (url) => set({ currentVideoUrl: url }),
  
  setSelectedLanguage: (lang) => set({ selectedLanguage: lang }),
  
  setProcessing: (isProcessing, step = "") => set({ isProcessing, processingStep: step }),
  
  setCurrentSummary: (summary) => set({ currentSummary: summary }),
  
  setSummaries: (summaries) => set({ summaries }),
  
  addSummary: (summary) => set((state) => ({ 
    summaries: [summary, ...state.summaries] 
  })),
  
  removeSummary: (id) => set((state) => ({ 
    summaries: state.summaries.filter((s) => s.id !== id) 
  })),
  
  toggleFavorite: (id) => set((state) => ({
    summaries: state.summaries.map((s) => 
      s.id === id ? { ...s, isFavorite: !s.isFavorite } : s
    ),
  })),
  
  setActiveTab: (tab) => set({ activeTab: tab }),
  
  setShowSubscriptionModal: (show) => set({ showSubscriptionModal: show }),
  
  reset: () => set(initialState),
}));
