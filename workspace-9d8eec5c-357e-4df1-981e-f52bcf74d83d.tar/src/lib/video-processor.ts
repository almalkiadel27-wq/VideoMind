import ZAI from 'z-ai-web-dev-sdk';
import { db } from './db';

// Types
interface VideoMetadata {
  platform: string;
  videoId: string | null;
  thumbnail: string | null;
  duration: number | null;
}

interface TranscriptResult {
  text: string;
  source: 'youtube' | 'asr' | 'cache' | 'none';
  language: string | null;
}

interface SummaryResult {
  videoTitle: string;
  mainIdea: string;
  keyPoints: string[];
  conclusion: string;
  fullSummary: string;
  keywords: string[];
  originalLanguage: string | null;
}

// Extract video metadata from URL
export function extractVideoMetadata(url: string): VideoMetadata {
  try {
    const urlObj = new URL(url);
    const hostname = urlObj.hostname.replace('www.', '');
    
    // YouTube
    if (hostname.includes('youtube.com') || hostname === 'youtu.be') {
      let videoId = null;
      if (hostname === 'youtu.be') {
        videoId = urlObj.pathname.slice(1).split('?')[0];
      } else if (urlObj.pathname.includes('/shorts/')) {
        videoId = urlObj.pathname.split('/shorts/')[1]?.split('?')[0];
      } else if (urlObj.pathname.includes('/embed/')) {
        videoId = urlObj.pathname.split('/embed/')[1]?.split('?')[0];
      } else {
        videoId = urlObj.searchParams.get('v');
      }
      return {
        platform: 'YouTube',
        videoId,
        thumbnail: videoId ? `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg` : null,
        duration: null
      };
    }
    
    // Vimeo
    if (hostname.includes('vimeo.com')) {
      const videoId = urlObj.pathname.split('/').filter(Boolean).pop()?.split('?')[0];
      return {
        platform: 'Vimeo',
        videoId,
        thumbnail: videoId ? `https://vumbnail.com/${videoId}.jpg` : null,
        duration: null
      };
    }
    
    // TikTok
    if (hostname.includes('tiktok.com')) {
      return { platform: 'TikTok', videoId: null, thumbnail: null, duration: null };
    }
    
    // Other platforms
    if (hostname.includes('instagram.com')) return { platform: 'Instagram', videoId: null, thumbnail: null, duration: null };
    if (hostname.includes('facebook.com') || hostname.includes('fb.watch')) return { platform: 'Facebook', videoId: null, thumbnail: null, duration: null };
    if (hostname.includes('twitter.com') || hostname.includes('x.com')) return { platform: 'Twitter/X', videoId: null, thumbnail: null, duration: null };
    if (hostname.includes('twitch.tv')) return { platform: 'Twitch', videoId: null, thumbnail: null, duration: null };
    if (hostname.includes('dailymotion.com') || hostname === 'dai.ly') {
      let videoId = null;
      if (hostname === 'dai.ly') {
        videoId = urlObj.pathname.slice(1);
      } else {
        videoId = urlObj.pathname.split('/video/')[1]?.split('?')[0];
      }
      return {
        platform: 'Dailymotion',
        videoId,
        thumbnail: videoId ? `https://www.dailymotion.com/thumbnail/video/${videoId}` : null,
        duration: null
      };
    }
    
    // Direct video
    const videoExtensions = ['.mp4', '.webm', '.ogg', '.mov', '.avi', '.mkv', '.m3u8', '.mpd'];
    const isDirectVideo = videoExtensions.some(ext => 
      urlObj.pathname.toLowerCase().endsWith(ext)
    );
    
    return { 
      platform: isDirectVideo ? 'Direct Video' : 'Video', 
      videoId: null, 
      thumbnail: null,
      duration: null
    };
  } catch {
    return { platform: 'Video', videoId: null, thumbnail: null, duration: null };
  }
}

// Check if video is already processed (cache)
export async function getCachedTranscript(videoUrl: string): Promise<TranscriptResult | null> {
  try {
    const cache = await db.videoCache.findUnique({
      where: { videoUrl }
    });
    
    if (cache?.transcript) {
      return {
        text: cache.transcript,
        source: 'cache',
        language: null
      };
    }
    return null;
  } catch {
    return null;
  }
}

// Save transcript to cache
export async function saveTranscriptToCache(
  videoUrl: string, 
  transcript: string, 
  source: string,
  metadata: VideoMetadata
): Promise<void> {
  try {
    await db.videoCache.upsert({
      where: { videoUrl },
      update: {
        transcript,
        transcriptSource: source,
        platform: metadata.platform,
        processedAt: new Date()
      },
      create: {
        videoUrl,
        transcript,
        transcriptSource: source,
        platform: metadata.platform,
        videoThumbnail: metadata.thumbnail
      }
    });
  } catch (error) {
    console.error('Failed to save to cache:', error);
  }
}

// Extract YouTube transcript using web search and page reading
export async function extractYouTubeTranscript(videoId: string, zai: Awaited<ReturnType<typeof ZAI.create>>): Promise<TranscriptResult | null> {
  try {
    // Search for video transcript
    const searchResults = await zai.functions.invoke('web_search', {
      query: `youtube ${videoId} transcript subtitles`,
      num: 3
    });
    
    if (searchResults && searchResults.length > 0) {
      // Try to read the transcript from search results
      for (const result of searchResults) {
        if (result.snippet && result.snippet.length > 100) {
          // Use the snippet as a base for content
          return {
            text: result.snippet,
            source: 'youtube',
            language: null
          };
        }
      }
    }
    
    return null;
  } catch (error) {
    console.error('YouTube transcript extraction failed:', error);
    return null;
  }
}

// Clean and prepare text for summarization
export function cleanTranscript(text: string): string {
  // Remove excessive whitespace
  text = text.replace(/\s+/g, ' ').trim();
  
  // Remove timestamps like [00:00:00]
  text = text.replace(/\[\d{2}:\d{2}:\d{2}\]/g, '');
  text = text.replace(/\[\d{2}:\d{2}\]/g, '');
  
  // Remove speaker labels like "Speaker 1:", "John:"
  text = text.replace(/^[A-Za-z\s]+:\s*/gm, '');
  
  // Remove duplicate sentences
  const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
  const uniqueSentences = [...new Set(sentences.map(s => s.trim()))];
  
  // Remove very short fragments
  const cleanSentences = uniqueSentences.filter(s => s.split(' ').length > 3);
  
  return cleanSentences.join('. ').trim();
}

// Split text into chunks for processing
export function splitIntoChunks(text: string, maxWords: number = 1000): string[] {
  const words = text.split(' ');
  const chunks: string[] = [];
  let currentChunk: string[] = [];
  let currentWordCount = 0;
  
  for (const word of words) {
    currentChunk.push(word);
    currentWordCount++;
    
    if (currentWordCount >= maxWords) {
      // Find a good breaking point (end of sentence)
      const lastPeriod = currentChunk.join(' ').lastIndexOf('.');
      if (lastPeriod > currentChunk.length * 0.7) {
        const chunkText = currentChunk.join(' ');
        chunks.push(chunkText.substring(0, lastPeriod + 1));
        currentChunk = chunkText.substring(lastPeriod + 1).split(' ').filter(w => w);
        currentWordCount = currentChunk.length;
      } else {
        chunks.push(currentChunk.join(' '));
        currentChunk = [];
        currentWordCount = 0;
      }
    }
  }
  
  if (currentChunk.length > 0) {
    chunks.push(currentChunk.join(' '));
  }
  
  return chunks;
}

// Summarize a single chunk
async function summarizeChunk(
  chunk: string, 
  zai: Awaited<ReturnType<typeof ZAI.create>>,
  targetLanguage: string
): Promise<string> {
  const completion = await zai.chat.completions.create({
    messages: [
      {
        role: 'user',
        content: `Summarize this video transcript segment in ${targetLanguage}. Extract the key points only:

"${chunk}"

Provide a concise summary in 2-3 sentences.`
      }
    ]
  });
  
  return completion.choices[0]?.message?.content || '';
}

// Generate partial summaries in parallel
export async function generatePartialSummaries(
  chunks: string[],
  zai: Awaited<ReturnType<typeof ZAI.create>>,
  targetLanguage: string
): Promise<string[]> {
  // Process chunks in parallel (max 3 at a time)
  const batchSize = 3;
  const results: string[] = [];
  
  for (let i = 0; i < chunks.length; i += batchSize) {
    const batch = chunks.slice(i, i + batchSize);
    const batchResults = await Promise.all(
      batch.map(chunk => summarizeChunk(chunk, zai, targetLanguage))
    );
    results.push(...batchResults);
  }
  
  return results;
}

// Generate final summary from partial summaries
export async function generateFinalSummary(
  partialSummaries: string[],
  zai: Awaited<ReturnType<typeof ZAI.create>>,
  targetLanguage: string,
  videoTitle?: string
): Promise<SummaryResult> {
  const combinedSummaries = partialSummaries.join('\n\n');
  
  const completion = await zai.chat.completions.create({
    messages: [
      {
        role: 'user',
        content: `Based on these partial summaries from a video, create a comprehensive summary in ${targetLanguage}.

Partial Summaries:
${combinedSummaries}

Return ONLY valid JSON (no markdown, no extra text):
{
  "videoTitle": "${videoTitle || 'Video Summary'}",
  "mainIdea": "The main idea in 2-3 sentences",
  "keyPoints": ["Point 1", "Point 2", "Point 3", "Point 4", "Point 5"],
  "conclusion": "Conclusion in 2-3 sentences",
  "fullSummary": "A detailed paragraph summary",
  "keywords": ["keyword1", "keyword2", "keyword3", "keyword4", "keyword5"],
  "originalLanguage": "Detected language of the original content"
}`
      }
    ]
  });
  
  const responseContent = completion.choices[0]?.message?.content;
  
  if (responseContent) {
    try {
      const jsonMatch = responseContent.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
    } catch (e) {
      console.error('JSON parse error:', e);
    }
  }
  
  // Fallback summary
  return {
    videoTitle: videoTitle || 'Video Summary',
    mainIdea: partialSummaries[0] || 'Unable to generate summary',
    keyPoints: partialSummaries.slice(1, 6),
    conclusion: partialSummaries[partialSummaries.length - 1] || '',
    fullSummary: combinedSummaries,
    keywords: [],
    originalLanguage: null
  };
}

// Main function: Get transcript from any source
export async function getVideoTranscript(
  videoUrl: string,
  metadata: VideoMetadata,
  zai: Awaited<ReturnType<typeof ZAI.create>>
): Promise<TranscriptResult> {
  // 1. Check cache first
  const cached = await getCachedTranscript(videoUrl);
  if (cached) {
    return cached;
  }
  
  // 2. Try YouTube transcript extraction
  if (metadata.platform === 'YouTube' && metadata.videoId) {
    const ytTranscript = await extractYouTubeTranscript(metadata.videoId, zai);
    if (ytTranscript && ytTranscript.text.length > 100) {
      await saveTranscriptToCache(videoUrl, ytTranscript.text, 'youtube', metadata);
      return ytTranscript;
    }
  }
  
  // 3. Search for video content online
  const searchQuery = `${metadata.platform} video ${metadata.videoId || ''} content summary`;
  const searchResults = await zai.functions.invoke('web_search', {
    query: searchQuery,
    num: 5
  });
  
  if (searchResults && searchResults.length > 0) {
    // Combine snippets into a transcript-like text
    const combinedText = searchResults
      .map((r: { name: string; snippet: string }) => `${r.name}: ${r.snippet}`)
      .join('\n\n');
    
    if (combinedText.length > 200) {
      await saveTranscriptToCache(videoUrl, combinedText, 'search', metadata);
      return {
        text: combinedText,
        source: 'youtube',
        language: null
      };
    }
  }
  
  return {
    text: '',
    source: 'none',
    language: null
  };
}

// Full video processing pipeline
export async function processVideo(
  videoUrl: string,
  targetLanguage: string
): Promise<SummaryResult> {
  const zai = await ZAI.create();
  
  // 1. Extract metadata
  const metadata = extractVideoMetadata(videoUrl);
  
  // 2. Get transcript
  const transcriptResult = await getVideoTranscript(videoUrl, metadata, zai);
  
  if (!transcriptResult.text || transcriptResult.text.length < 50) {
    throw new Error('Could not extract video content. Please try a different video.');
  }
  
  // 3. Clean transcript
  const cleanedText = cleanTranscript(transcriptResult.text);
  
  // 4. Split into chunks
  const chunks = splitIntoChunks(cleanedText, 800);
  
  // 5. Generate partial summaries in parallel
  const partialSummaries = await generatePartialSummaries(chunks, zai, targetLanguage);
  
  // 6. Generate final summary
  const finalSummary = await generateFinalSummary(
    partialSummaries, 
    zai, 
    targetLanguage,
    metadata.platform + ' Video'
  );
  
  // 7. Save to cache
  await saveTranscriptToCache(videoUrl, cleanedText, transcriptResult.source, metadata);
  
  return finalSummary;
}
